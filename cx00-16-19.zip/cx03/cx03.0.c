/* *******************************************************
 * Nom           : cx03.0.c
 * Rôle          : Afficher le premier argument
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx03.0.c -o cx03.0
 * Usage         : ./cx03.0 fonctionne
 *               : ./cx03.0 fonctionne avec cinq arguments
 *               : ./cx03.0 se bouffe des arguments sur la ligne de commande
 *               : ./cx03.0
 * *******************************************************/

/* Enoncé:
 * compilons-le, exécutons-le, même sans argument, et nous constaterons qu'il produit exactement le même effet. En fait,
 * quelque soit le nombre d'arguments sur la ligne de commande, ils sont totalement ignorés, puisque le programme
 * n'affiche que la première valeur de argv.
 */

#include <stdio.h> // directive d'inclusion

#define str char * // directive de substitution

int main(int k, const str argv[]) { puts(*argv); return 0; }
