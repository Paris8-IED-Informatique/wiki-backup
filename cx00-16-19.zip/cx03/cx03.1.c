/* *******************************************************
 * Nom           : cx03.1.c
 * Rôle          : Afficher les arguments
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx03.1.c -o cx03.1
 * Usage         : ./cx03.1 fonctionne
 *               : ./cx03.1 fonctionne avec cinq arguments
 *               : ./cx03.1 se bouffe des arguments sur la ligne de commande
 *               : ./cx03.1
 * *******************************************************/

/* Enoncé:
 * compiler et exécuter le code ci-dessus; l'essayer en l'appelant avec les arguments suivants:
 *   cx03.1 et ses arguments
 * Obtenez-vous le résultat attendu ?
 */

/* Répoonse:
 * On obtient bien la même chose que précédemment: le nom du programme puis les arguments, un par ligne. */

#include <stdio.h> // directive d'inclusion

#define str char * // directive de substitution

int main(int k, const str argv[]) { while (* argv) puts(* argv ++) ; return 0 ; }
