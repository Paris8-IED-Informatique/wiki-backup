/* *******************************************************
 * Nom           : cx03.4.c
 * Rôle          : Affiche les arguments par récursivité
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx03.4.c -o cx03.4
 * Usage         : ./cx03.4 fonctionne
 *               : ./cx03.4 fonctionne avec cinq arguments
 *               : ./cx03.4 se bouffe des arguments sur la ligne de commande
 *               : ./cx03.4
 * *******************************************************/

/* Enoncé:
 * compiler et exécuter le code ci-dessus, avec un nombre quelconque d'arguments.
 */


#include <stdio.h>

int main(int x, char * L[]) {
    if(*L) {
        puts(*L);
        return main(x - 1, L + 1);
    }
    return 0;
}