/* *******************************************************
 * Nom           : cx03.3.c
 * Rôle          : Afficher les arguments sauf le nom du programme et à l'envers.
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx03.3.c -o cx03.3
 * Usage         : ./cx03.3 fonctionne
 *               : ./cx03.3 fonctionne avec cinq arguments
 *               : ./cx03.3 se bouffe des arguments sur la ligne de commande
 *               : ./cx03.3
 * *******************************************************/

/* Enoncé:
 * modifier le programme de sorte que argv soit redéfini par argv += k, puis l'utiliser dans une boucle while
 * régressive, affichant les arguments à l'envers...
 */

/* Répoonse:
 * Comme on va à l'envers, on ne peut plus utiliser l'astuce de la valeur NULL pour avoir quand s'arrêter.
 * On va donc définir une variable locale start initialisée avec la valeur de argv (càd le début du tableau).
 * On modifie ensuite la valeur de argv (+= k) comme demandé dans l'énoncé.
 * La condition d'arrêt de la boucle while est argv > start car on veut s'arrêter juste après start pour éviter
 * d'afficher le premier argument (le nom du programme).
 * On décrémente argv à chaque tour de la boucle. On utilise un pré-décrémentation car argv pointe sur l'élément
 * suivant (car on démarre après la fin du tableau) */

#include <stdio.h> // directive d'inclusion

#define str char * // directive de substitution

int main(int k, const str argv[])
{
    const str *start = argv; // Début du tableau, pour pouvoir arrêter la boucle.
    argv += k; // On se positionne après la fin du tableau
    while (argv > start) puts(*--argv); // Tant que l'on est pas au début, on décrémente argv et on affiche l'argument
    return 0;
}

/* Le cours propose une méthode de "vandales" alternative qui consiste à modifier le tableau des arguments et à
 * remplacer le premier argument (le nom du programme) par NULL. */

/*
int main(int k, const str argv[])
{
    *argv = NULL; // Méthode de "vandale"
    argv += k; // On se positionne après la fin du tableau
    while (*--argv) puts(*argv); // On décrémente argv et tant que l'on est pas au début, on affiche l'argument
    return 0;
}*/
