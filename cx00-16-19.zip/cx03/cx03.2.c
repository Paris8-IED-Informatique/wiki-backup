/* *******************************************************
 * Nom           : cx03.2.c
 * Rôle          : Afficher les arguments sauf le nom du programme.
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx03.2.c -o cx03.2
 * Usage         : ./cx03.2 fonctionne
 *               : ./cx03.2 fonctionne avec cinq arguments
 *               : ./cx03.2 se bouffe des arguments sur la ligne de commande
 *               : ./cx03.2
 * *******************************************************/

/* Enoncé:
 * le premier mot de la ligne de commande est rarement intéressant, puisque c'est le nom du programme!; modifier le
 * programme pour qu'il « saute » le premier élément et ne commence son affichage qu'à partir du deuxième élément.
 * Rien n'empêche d'ajouter directement une valeur à un pointeur: sachant que k est le nombre d'éléments utiles dans la
 * séquence argv, alors argv + k est l'adresse du dernier élément de argv, autrement dit NULL.
 */

/* Répoonse:
 * Il suffit d'incrémenter argv pour débuter la boucle sur le deuxième élément. */

#include <stdio.h> // directive d'inclusion

#define str char * // directive de substitution

int main(int k, const str argv[])
{
    ++argv; // On "saute" le premier élément qui est le nom du programme en incrémentant argv.
    while (* argv) puts(*argv++);
    return 0;
}
