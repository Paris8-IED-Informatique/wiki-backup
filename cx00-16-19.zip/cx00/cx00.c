#include <stdio.h>

int main() { puts("affichage") ; return 0 ; }
