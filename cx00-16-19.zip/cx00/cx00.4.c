/* *******************************************************
 * Nom           : cx00.4.c
 * Rôle          : Code de retour
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx00.4.c -o cx00.4
 * Usage         : ./cx00.4
 *                 echo $?
 * *******************************************************/

/* Enoncé:
 * modifier ce programme pour qu'il retourne un code d'erreur différent de 0 (et de 256), et en tester la valeur avec
 * la commande shell echo $? */


#include <stdio.h>

int main() {
    puts("Matin d'hiver");
    puts("sur une carotte en guise de nez");
    puts("un éphémère se pose");
    puts("");
    puts("Matin printanier");
    puts("une main verte et ridée");
    puts("un jardinier peu pressé");
    puts("");
    puts("Matin d'été");
    puts("deux vieilles branches se saluent");
    puts("l'un est chêne, l'autre est figuier");
    puts("");
    puts("Matin d'automne");
    puts("sur un arbre centenaire");
    puts("une palette de couleurs");
    return 1; // Code d'erreur différent de 0
}

