/* *******************************************************
 * Nom           : cx00.1.c
 * Rôle          : Afficher "quelque chose de bien"
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx00.1.c -o cx00.1
 * Usage         : ./cx00.1
 * *******************************************************/

/* Enoncé:
 * modifier ce programme pour qu'il affiche "quelque chose de bien". */

/* Explications:
 * Il est toujours possible de compiler. Suivant le compilateur, celui-ci peut générer une alerte:
 * "warning: type specifier missing, defaults to 'int'"
 * En l'absence d'un type de retour pour main, le compilateur va considérer implicitement que c'est un int.
 */

#include <stdio.h>

int main() { puts("quelque chose de bien") ; return 0 ; }

