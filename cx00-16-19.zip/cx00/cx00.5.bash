#!/usr/bin/env bash
# *******************************************************
# Nom           : cx00.5.bash
# Rôle          : Test du programme cx00.5
# Auteur        : Britney Spears
# Version       : 1.0
# Date          : 2021-04-28
# Licence       : L1 PROGC
# *******************************************************
# Usage         : bash cx00.5.bash
# *******************************************************

./cx00.5
echo $?
