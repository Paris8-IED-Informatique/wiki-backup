/* *******************************************************
 * Nom           : cx00.0.c
 * Rôle          : Expérimenter avec main
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx00.0.c -o cx00.0
 * Usage         : ./cx00.0
 * *******************************************************/

/* Enoncé:
 * entrer le code ci-dessus dans un fichier, le compiler, et l'exécuter !: peut-il encore être compilé si on supprime
 * le mot int, juste avant main!? */

/* Explications:
 * Il est toujours possible de compiler. Suivant le compilateur, celui-ci peut générer une alerte:
 *   warning: type specifier missing, defaults to 'int'
 * En l'absence d'un type de retour pour main, le compilateur va considérer implicitement que c'est un int.
 */

#include <stdio.h>

main() { puts("affichage") ; return 0 ; }

