/* *******************************************************
 * Nom           : cx00.2.c
 * Rôle          : Afficher sur deux lignes
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx00.2.c -o cx00.2
 * Usage         : ./cx00.2
 * *******************************************************/

/* Enoncé:
 * ajouter une nouvelle instruction après la première, de sorte que le programme affiche en plus: "sur deux lignes"
 * (attention: une chaîne de caractères doit être délimitée (encadrée) par des guillemets, et toute parenthèse ouverte
 * doit être refermée!; prenez garde à ne pas oublier de ponctuer l'instruction avec un point-virgule); essayer
 * d'ajouter cette instruction après l'instruction return: est-ce qu'elle s'exécute ? */

/* Explications:
 * Les instructions après le return ne sont pas exécutées.
 */

#include <stdio.h>

int main() {
    puts("quelque chose de bien");
    puts("sur deux lignes");
    return 0;
    puts("après return"); // N'est pas exécutée
}

