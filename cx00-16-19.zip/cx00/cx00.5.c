/* *******************************************************
 * Nom           : cx00.5.c
 * Rôle          : Sans code de retour explicite
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx00.5.c -o cx00.5
 * Usage         : ./cx00.5
 *                 echo $?
 * *******************************************************/

/* Enoncé:
 * modifier ce programme pour qu'il ne retourne rien du tout, et en tester la valeur avec la commande shell ci-dessus -
 * que peut-on en conclure ? */

/* Explications:
 * Suivant le compilateur, on peut avoir une alerte:
 *   warning: return type of 'main' is not 'int'
 * echo $? retourne 0, même si main ne retourne rien. Il y a une valeur de retour implicite générée par le compilateur.*/

#include <stdio.h>

int main() {
    puts("Matin d'hiver");
    puts("sur une carotte en guise de nez");
    puts("un éphémère se pose");
    puts("");
    puts("Matin printanier");
    puts("une main verte et ridée");
    puts("un jardinier peu pressé");
    puts("");
    puts("Matin d'été");
    puts("deux vieilles branches se saluent");
    puts("l'un est chêne, l'autre est figuier");
    puts("");
    puts("Matin d'automne");
    puts("sur un arbre centenaire");
    puts("une palette de couleurs");
    // Pas de code de retour explicite
}


