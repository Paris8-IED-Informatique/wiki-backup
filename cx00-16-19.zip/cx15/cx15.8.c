/* *******************************************************
 * Nom           : cx15.8.c
 * Rôle          : Lecture de mots et de nombres depuis un fichier
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx15.8.c -o cx15.8
 * Usage         : ./cx15.8 cx15.8.txt
 * *******************************************************/

/* Enoncé:
 * modifier encore le fichier de données en y mettant des nombres réels: comment le format %i interprète-t-il le
 * point décimal ? Essayer de lire les mêmes données avec les formats %f, puis %2f et aussi %4f; est-ce que ça produit
 * des différences de lecture ?
 */

/* Explications:
 * %i va interpréter le point décimal comme un caractère invalide et va donc retourner une erreur.
 *
 * Pour utiliser le format %f, nous devons faire plusieurs modifications dans le programme. Il faut remplacer %i par %f
 * mais aussi le type de données de nombres. Ce doit être un tableau de float. Une fois ces changements fait, fscanf
 * interprète correctement le point décimal et le programme affiche les nombres:
 *   3 mots : programme compilateur assembleur
 *   3 nombres : 1.200000 3.400000 5.600000
 *
 * Si on remplace %f par %2f, nous obtenons (pour le même fichier de données) le résultat suivant:
 *   3 mots : programme compilateur assembleur
 *   6 nombres : 1.000000 2.000000 3.000000 4.000000 4.000000 6.000000
 * En effet, le 2 entre le % et le f indique le nombre maximum de caractères que fscanf doit considérer, en l'occurrence
 * 2 caractères. Donc quand fscanf rencontre la chaine "1.2", elle interprète les deux premiers caractères "1." ce qui
 * donne le nombre (décimal) 1. Puis lors du deuxième appel, elle reprend là où elle s'est arrêtée. Elle rencontre "2 "
 * ce qui est interprété comme étant le nombre (décimal) 2. Et ainsi de suite.
 *
 * Si on remplace %2f par %4f, on obtient (avec notre fichier de test) le même résultat qu'avec %f. En effet, on indique
 * à fscanf de lire au maximum 4 caractères. Or nos nombres font 3 caractères. Si on met des nombres décimaux plus
 * grands que 4 caractères, on retombe dans le cas précédent.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


// Prototype
void usage(const char * program);


int main(int k, char * ldc[]) {
    if(k < 2) usage("il me faut un nom de fichier");  // incontournable !
    FILE * zap = fopen(ldc[1], "r");  // ouverture du flux
    if(!zap) usage("fichier pas lisible");  // si flux invalide, dégage
    char * mots[4];  // espace pour 3 chaînes. Non c'est faux: pour 4 chaines
    int lu = 0, max, x;  // quelques compteurs
    for(max = 0; max < 3 && lu != EOF; ++max) {
        char nouveau[32];  // sas 32 caractères
        lu = fscanf(zap, "%s", nouveau);  // acquisition
        mots[max] = strdup(nouveau);  // copie propre
    }
    if(lu == EOF) --max; // Si on a atteint la fin du fichier, max est trop grand d'une unité
    printf("%i mots : ", max);  // régurgitation
    for (x = 0; x < max; ++x)  // max le fait !
        printf("%s ", mots[x]);  // affiche le mot
    puts("");  // saute une ligne
    //int nombres[10];  // espace pour 10 entiers
    float nombres[10];  // version pour %f
    for (max = 0; max < 10 && lu != EOF; max++) {
        // lu = fscanf(zap, "%i", nombres + max);  // acquisition
        // lu = fscanf(zap, "%f", nombres + max);  // version avec %f
        // lu = fscanf(zap, "%2f", nombres + max);  // version avec %2f
        lu = fscanf(zap, "%4f", nombres + max);  // version avec %4f
        // Si le nombre n'a pas pu être lu, on affiche un message et on sort de la fonction.
        if(!lu) usage("Un élément n'est pas un nombre.");
    }
    if(lu == EOF) --max; // Si on a atteint la fin du fichier, max est trop grand d'une unité
    printf("%i nombres : ", max);  // régurgitation avec correction du bug
    for (x = 0; x < max; x++)  // est-ce que max le fait-il ?
        // printf("%i ", nombres[x]);  // affiche le nombre
        printf("%f ", nombres[x]);  // version avec %f
    puts("");  // saute une ligne
    fclose(zap);  // ferme bien

    // Attention: fuite de mémoire (mémoire allouée par strdup)

    return 0;  // arrête
}

// Explique comment utiliser le programme
void usage(const char * message) {
    printf("%s\n\n", message);
    printf("Usage : cx15.8 nom_fichier\n\n");
    printf("Le programme ouvre un fichier dont le nom est nom_fichier et lit trois mots et trois nombres.\n\n");
    printf("Exemples d'utilisation:\n");
    printf("cx15.8 cx15.8.txt\n");
    exit(1);
}
