/* *******************************************************
 * Nom           : cx15.3.c
 * Rôle          : Lecture de mots depuis un fichier
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx15.3.c -o cx15.3
 * Usage         : ./cx15.3 cx15.3.data
 * *******************************************************/

/* Enoncé:
 * Créer le fichier texte cx15.3.data contenant Joe Jack William Averell (ces mots peuvent être séparés par des espaces,
 * des tabulations, ou des sauts de ligne), et coder le programme qui lit cette information dans une table (ou vecteur)
 * de chaînes comme ci-dessus.
 */

/* Explications:
 * Le fichier à lire contient 4 mots. On adapte donc le programme donné dans le cours pour 4 mots. Le commentaire
 * dans code du cours au niveau de la déclaration de mots (" + élément NULL") semble suggérer que nous devons utiliser
 * un tableau d'un élément plus grand et mettre NULL dans le dernier élément. Cela peut être utile dans une boucle pour
 * détecter la fin du tableau sans connaitre sa taille. Nous plaçons donc NULL dans le dernier élément après avoir lu
 * tous les mots.
 * A noter que ce programme comporte un bug: la mémoire allouée par les différents appels à strdup n'est jamais rendue
 * au système. On a une fuite mémoire. Pour être totalement correcte, on devrait parcourir tout le tableau et appeller
 * free pour chaque élément non NULL.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Prototype
void usage(const char * program);
void read_strings(FILE *file, char * mots[5]);

int main(int k, char * ldc[]) {
    if(k != 2) usage(ldc[0]); // On attend 1 argument (en plus du nom du programme)

    char * mots[5]; // vecteur de 4 mots + élément NULL

    FILE * file = fopen(ldc[1], "r"); // ouverture du fichier en lecture
    if(!file) { printf("Le fichier '%s' n'a pas pu être ouvert en lecture.\n\n", ldc[1]); usage(ldc[0]); }
    read_strings(file, mots); // lecture des mots
    fclose(file); // fermeture du fichier

    // Attention: fuite de mémoire (mémoire allouée par strdup)

    return 0;
}

void read_strings(FILE *file, char * mots[5]) {
    int lu, max; // caractères lus, compteur
    for(max = 0; max < 4; ++max) { // lit 4 mots
        char sas[32]; // buffer : le plus long mot français fait 25
        lu = fscanf(file, "%s", sas); // met le mot dans le sas
        mots[max] = strdup(sas); // recopie-le ailleurs
    }

    // On termine le tableau par un élément NULL
    mots[max] = NULL;
}

// Explique comment utiliser le programme
void usage(const char * program) {
    printf("Usage : %s nom_fichier\n\n", program);
    printf("Le programme ouvre un fichier dont le nom est nom_fichier et lit 3 mots.\n\n");
    printf("Exemples d'utilisation:\n");
    printf("%s cx15.3.data\n", program);
    exit(1);
}
