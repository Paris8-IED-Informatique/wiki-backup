/* *******************************************************
 * Nom           : cx15.6.c
 * Rôle          : Lecture de mots et de nombres depuis un fichier
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx15.6.c -o cx15.6
 * Usage         : ./cx15.6 cx15.6.txt
 * *******************************************************/

/* Enoncé:
 * coder ce programme (complété avec des tests EOF si besoin) et le faire tourner sur votre propre fichier de données,
 * dont le nom sera passé en argument par la ligne de commande.
 *
 * Remarquez que la façon dont les mots sont séparés dans le fichier n'a aucune importance: sauts de lignes, espaces
 * multiples et tabulations sont du « WHITESPACE » – considérés comme neutres, et ignorés par fscanf(). Mais comment
 * est-ce que ça se passe si on met l'expression de plusieurs mots entre guillemets ?
 */

/* Explications:
 * Comme pour l'exercice cx15.0, le code tel que donné dans le cours comporte un bug: lorsque l'on a pu lire tous les
 * nombres, max a la bonne valeur. Donc on va décrémenter max, mais uniquement en cas d'arrêt prématuré de la lecture
 * (fin de fichier).
 *
 * Le cours semble aussi faire une confusion entre les chaines de caractères (qui se terminent par un NULL) et les
 * tableaux de chaines de caractères (qui n'ont pas besoin de prévoir un élément de plus).
 *
 * A noter aussi que ce programme comporte un bug: la mémoire allouée par les différents appels à strdup n'est jamais
 * rendue au système. On a une fuite mémoire. Pour être totalement correcte, on devrait parcourir tout le tableau et
 * appeller free pour chaque élément non NULL.
 *
 * Si on met plusieurs mots entre guillemets, notre programme n'en tient pas compte. En effet, fscanf n'est pas conçue
 * pour cela: elle ne traite les séparateurs tels que les espaces, les tabulations et les retours à la ligne. Donc si
 * on utilise des guillemets, notre programme va produire une erreur telle que:
 *
 * Un élément n'est pas un nombre.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


// Prototype
void usage(const char * program);


int main(int k, char * ldc[]) {
    if(k < 2) usage("il me faut un nom de fichier");  // incontournable !
    FILE * zap = fopen(ldc[1], "r");  // ouverture du flux
    if(!zap) usage("fichier pas lisible");  // si flux invalide, dégage
    char * mots[4];  // espace pour 3 chaînes. Non c'est faux: pour 4 chaines
    int lu = 0, max, x;  // quelques compteurs
    for(max = 0; max < 3 && lu != EOF; ++max) {
        char nouveau[32];  // sas 32 caractères
        lu = fscanf(zap, "%s", nouveau);  // acquisition
        mots[max] = strdup(nouveau);  // copie propre
    }
    if(lu == EOF) --max; // Si on a atteint la fin du fichier, max est trop grand d'une unité
    printf("%i mots : ", max);  // régurgitation
    for (x = 0; x < max; ++x)  // max le fait !
        printf("%s ", mots[x]);  // affiche le mot
    puts("");  // saute une ligne
    int nombres[10];  // espace pour 10 entiers
    for (max = 0; max < 10 && lu != EOF; max++) {
        lu = fscanf(zap, "%i", nombres + max);  // acquisition
        // Si le nombre n'a pas pu être lu, on affiche un message et on sort de la fonction.
        if(!lu) usage("Un élément n'est pas un nombre.");
    }
    if(lu == EOF) --max; // Si on a atteint la fin du fichier, max est trop grand d'une unité
    printf("%i nombres : ", max);  // régurgitation avec correction du bug
    for (x = 0; x < max; x++)  // est-ce que max le fait-il ?
        printf("%i ", nombres[x]);  // affiche le nombre
    puts("");  // saute une ligne
    fclose(zap);  // ferme bien

    // Attention: fuite de mémoire (mémoire allouée par strdup)

    return 0;  // arrête
}

// Explique comment utiliser le programme
void usage(const char * message) {
    printf("%s\n\n", message);
    printf("Usage : cx15.6 nom_fichier\n\n");
    printf("Le programme ouvre un fichier dont le nom est nom_fichier et lit trois mots et trois nombres.\n\n");
    printf("Exemples d'utilisation:\n");
    printf("cx15.6 cx15.6.txt\n");
    exit(1);
}
