/* *******************************************************
 * Nom           : cx15.7.c
 * Rôle          : Lecture de mots et de nombres depuis un fichier
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx15.7.c -o cx15.7
 * Usage         : ./cx15.7 cx15.7.txt
 * *******************************************************/

/* Enoncé:
 * modifier le fichier de données en n'y mettant que des nombres: sans changer le programme, comment les 3 premiers
 * nombres sont-ils interprétés par fscanf() ?
 */

/* Explications:
 * fscanf suit à la lettre ce qu'on lui demande de faire: Elle interprète les 3 premières données comme étant des
 * chaines de caractères en suivant le template "%s". nouveau va donc contenir une suite de caractères, ces caractères
 * étant les chiffres du nombre.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


// Prototype
void usage(const char * program);


int main(int k, char * ldc[]) {
    if(k < 2) usage("il me faut un nom de fichier");  // incontournable !
    FILE * zap = fopen(ldc[1], "r");  // ouverture du flux
    if(!zap) usage("fichier pas lisible");  // si flux invalide, dégage
    char * mots[4];  // espace pour 3 chaînes. Non c'est faux: pour 4 chaines
    int lu = 0, max, x;  // quelques compteurs
    for(max = 0; max < 3 && lu != EOF; ++max) {
        char nouveau[32];  // sas 32 caractères
        lu = fscanf(zap, "%s", nouveau);  // acquisition
        mots[max] = strdup(nouveau);  // copie propre
    }
    if(lu == EOF) --max; // Si on a atteint la fin du fichier, max est trop grand d'une unité
    printf("%i mots : ", max);  // régurgitation
    for (x = 0; x < max; ++x)  // max le fait !
        printf("%s ", mots[x]);  // affiche le mot
    puts("");  // saute une ligne
    int nombres[10];  // espace pour 10 entiers
    for (max = 0; max < 10 && lu != EOF; max++) {
        lu = fscanf(zap, "%i", nombres + max);  // acquisition
        // Si le nombre n'a pas pu être lu, on affiche un message et on sort de la fonction.
        if(!lu) usage("Un élément n'est pas un nombre.");
    }
    if(lu == EOF) --max; // Si on a atteint la fin du fichier, max est trop grand d'une unité
    printf("%i nombres : ", max);  // régurgitation avec correction du bug
    for (x = 0; x < max; x++)  // est-ce que max le fait-il ?
        printf("%i ", nombres[x]);  // affiche le nombre
    puts("");  // saute une ligne
    fclose(zap);  // ferme bien

    // Attention: fuite de mémoire (mémoire allouée par strdup)

    return 0;  // arrête
}

// Explique comment utiliser le programme
void usage(const char * message) {
    printf("%s\n\n", message);
    printf("Usage : cx15.7 nom_fichier\n\n");
    printf("Le programme ouvre un fichier dont le nom est nom_fichier et lit trois mots et trois nombres.\n\n");
    printf("Exemples d'utilisation:\n");
    printf("cx15.7 cx15.7.txt\n");
    exit(1);
}
