/* *******************************************************
 * Nom           : cx15.5.c
 * Rôle          : Lecture de noms et de nombres depuis un fichier
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx15.5.c -o cx15.5
 * Usage         : ./cx15.5 cx15.5.data
 * *******************************************************/

/* Enoncé:
 * créer un nouveau fichier, cx15.5.data, où les noms sont associés à la cote de popularité du personnage:
 * Joe 1 Averell 4 Lucky Luke 10...
 * Modifier le programme [cx15.3] pour garnir en parallèle une table des noms et une table des scores. Peut-on coder
 * une solution généralisée indépendante du nombre de paires d'éléments ?
 */

/* Explications:
 * Pour avoir une solution totalement générique et qui marche quel que soit le nombre de mots (seulement limitée par la
 * quantité de mémoire disponible), il faudrait recourir à une allocation dynamique de mémoire (malloc, realloc, ...)
 * Mais ce n'a pas encore été abordé. Donc à la place, nous allons utiliser deux grands tableaux fixes et nous allons
 * détecter la fin du fichier comme vu précédemment (cx15.0 et cx15.1).
 * La fonction de lecture s'appelle read_popularities et prend les deux tableaux en paramètres (comme dans les exercices
 * précédents, j'ai préféré ne pas encombrer le main et donc utiliser une fonction ad-hoc. Cette fonction est un peu
 * plus complexe que précédemment car nous devons lire deux informations: le nom et la popularité et nous pouvons avoir
 * des problèmes de lecture à plusieurs moments. Par exemple, notre fichier se termine peut-être avec juste un nom et
 * pas de nombre. Nous allons tenir compte de tous ces cas.
 *
 * A noter que ce programme comporte un bug: la mémoire allouée par les différents appels à strdup n'est jamais rendue
 * au système. On a une fuite mémoire. Pour être totalement correcte, on devrait parcourir tout le tableau et appeler
 * free pour chaque élément non NULL.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NB_NAMES_MAX 700 // Nombre maximum de couples nom/popularité à lire

// Prototypes
void usage(const char * program);
void read_popularities(FILE *file, char * names[NB_NAMES_MAX], unsigned popularity[NB_NAMES_MAX]);


int main(int k, char * ldc[]) {
    if(k != 2) usage(ldc[0]); // On attend 1 argument (en plus du nom du programme)

    char * names[NB_NAMES_MAX+1]; // vecteur de NB_NAMES_MAX noms + élément NULL
    unsigned popularities[NB_NAMES_MAX+1]; // vecteur de NB_NAMES_MAX popularité + élément 0

    FILE * file = fopen(ldc[1], "r"); // ouverture du fichier en lecture
    if(!file) { printf("Le fichier '%s' n'a pas pu être ouvert en lecture.\n\n", ldc[1]); usage(ldc[0]); }
    read_popularities(file, names, popularities); // lecture des popularités
    fclose(file); // fermeture du fichier

    // Attention: fuite de mémoire (mémoire allouée par strdup)

    return 0;
}

void read_popularities(FILE *file, char * names[NB_NAMES_MAX], unsigned popularity[NB_NAMES_MAX]) {
    int lu = 0, max; // caractères lus, compteur
    for(max = 0; max < NB_NAMES_MAX && lu != EOF; ++max) { // lit NB_WORDS_MAX mots
        char sas[32]; // buffer : le plus long mot français fait 25
        lu = fscanf(file, "%s", sas); // met le mot dans le sas
        if(lu != EOF) { // Est-ce que l'on a pu lire un nom (on n'est pas encore arrivé à la fin du fichier) ?
            names[max] = strdup(sas); // recopie-le
            lu = fscanf(file, "%d", &popularity[max]); // Lecture de la popularité
            // Si le nombre n'a pas pu être lu, on affiche un message et on sort de la fonction.
            if(!lu) { printf("La popularité numéro %d (pour %s) n'a pas pu être lue.\n", max, names[max]); return; }
            if(lu == EOF) { printf("Il manque la popularité numéro %d (pour %s).\n", max, names[max]); return; }
        }
    }

    // Si on n'a pas pu lire tous les nombres, max a une unité de trop (car on a essayé de lire le nom)
    // donc on le décrémente de 1. Mais seulement dans ce cas-là. Si tous les noms/popularités ont été lus, max a la bonne
    // valeur.
    if(lu == EOF)
        --max;

    // On termine les tableaux par NULL et 0
    names[max] = NULL;
    popularity[max] = 0;
}


// Explique comment utiliser le programme
void usage(const char * program) {
    printf("Usage : %s nom_fichier\n\n", program);
    printf("Le programme ouvre un fichier dont le nom est nom_fichier et lit des suites de noms et de popularités"
           "(nombres).\n\n");
    printf("Exemples d'utilisation:\n");
    printf("%s cx15.5.data\n", program);
    exit(1);
}
