/* *******************************************************
 * Nom           : cx15.0.c
 * Rôle          : Lecture de 10 entiers depuis un fichier
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx15.0.c -o cx15.0
 * Usage         : ./cx15.0 cx15.0.txt
 * *******************************************************/

/* Enoncé:
 * compléter le code ci-dessus pour en faire un programme qui lit 10 entiers dans un fichier dont le nom est passé sur
 * la ligne de commande.
 */

/* Explications:
 * Le code tel que donné dans le cours comporte un bug. L'explication à propos de la valeur de max pour la lecture de
 * seulement 3 nombres (càd que max sera incrémenté à 4). Mais cette explication (et le code) oublie le cas normal:
 * lorsque l'on a pu lire tous les nombres, max a la bonne valeur. Donc on va décrémenter max, mais uniquement en cas
 * d'arrêt prématuré de la lecture (fin de fichier).
 *
 * Note: Le programme dans le cours comporte un bug. lu n'a pas de valeur au tout début et peut contenir n'importe quoi
 * lorsque la variable est déclarée. En effet, le C n'initialise pas automatiquement les variables (sauf les variables
 * statiques). Cf. http://c-faq.com/decl/initval.html Donc lu peut contenir, par malchance, la valeur EOF (-1) avant la
 * boucle for. Et par conséquent, la boucle va s'arrêter avant d'avoir commencée.
 */

#include <stdio.h>
#include <stdlib.h>

// Prototype
void usage(const char * program);
void read_display_integers(FILE *file);

int main(int k, char * ldc[]) {
    if(k != 2) usage(ldc[0]); // On attend 1 argument (en plus du nom du programme)

    FILE * file = fopen(ldc[1], "r") ;
    if(!file) { printf("Le fichier '%s' n'a pas pu être ouvert en lecture.\n\n", ldc[1]); usage(ldc[0]); }
    read_display_integers(file);
    fclose(file);
    return 0;
}

void read_display_integers(FILE *file) {
    int max, x, lu = 0, nombres[10]; // Correction du bug avec l'initialisation de lu
    // Lecture des nombres dans le fichier, maximum 10 nombres
    for(max = 0; max < 10 && lu != EOF; max++)
        lu = fscanf(file, "%d", & nombres[max]);
    // Si on n'a pas pu lire tous les nombres, max a une unité de trop (car on a essayé de lire le nombre)
    // donc on le décrémente de 1. Mais seulement dans ce cas-là. Si tous les nombres ont été lus, max a la bonne valeur.
    if(lu == EOF)
        --max;
    // On affiche les nombres
    for(x = 0; x < max; x++)
        printf("%i ", nombres[x]);
}

// Explique comment utiliser le programme
void usage(const char * program) {
    printf("Usage : %s nom_fichier\n\n", program);
    printf("Le programme ouvre un fichier dont le nom est nom_fichier, lit et affiche 10 entiers.\n\n");
    printf("Exemples d'utilisation:\n");
    printf("%s cx15.0.txt\n", program);
    exit(1);
}
