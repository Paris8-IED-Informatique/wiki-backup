/* *******************************************************
 * Nom           : cx15.1.c
 * Rôle          : Lecture de 10 entiers depuis un fichier
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx15.1.c -o cx15.1
 * Usage         : ./cx15.1 cx15.0.txt
 * *******************************************************/

/* Enoncé:
 * essayer avec un autre nombre d'éléments: faut-il modifier le code s'il y en a trop, ou pas assez ? Comment savoir
 * le nombre d'éléments effectivement lus dans tous les cas ?.
 */

/* Explications:
 * Le code permet bien de lire 10 nombres au maximum et moins si le fichier n'en contient pas 10. Le nombre d'éléments
 * effectivement lu est donné par max. On modifie la fonction pour le retourner et main va l'afficher avec un petit
 * message.
 */

#include <stdio.h>
#include <stdlib.h>

// Prototype
void usage(const char * program);
int read_display_integers(FILE *file);

int main(int k, char * ldc[]) {
    if(k != 2) usage(ldc[0]); // On attend 1 argument (en plus du nom du programme)

    FILE * file = fopen(ldc[1], "r") ;
    if(!file) { printf("Le fichier '%s' n'a pas pu être ouvert en lecture.\n\n", ldc[1]); usage(ldc[0]); }
    int nb = read_display_integers(file);
    printf("\n%d éléments ont été lus et affichés\n", nb);
    fclose(file);
    return 0;
}

int read_display_integers(FILE *file) {
    int max, x, lu = 0, nombres[10]; // Correction du bug avec l'initialisation de lu
    // Lecture des nombres dans le fichier, maximum 10 nombres
    for(max = 0; max < 10 && lu != EOF; max++)
        lu = fscanf(file, "%d", & nombres[max]);
    // Si on n'a pas pu lire tous les nombres, max a une unité de trop (car on a essayé de lire le nombre)
    // donc on le décrémente de 1. Mais seulement dans ce cas-là. Si tous les nombres ont été lus, max a la bonne valeur.
    if(lu == EOF)
        --max;
    // On affiche les nombre
    for(x = 0; x < max; x++)
        printf("%i ", nombres[x]);
    // On retourne max, le nombre d'éléments effectivement lus.
    return max;
}

// Explique comment utiliser le programme
void usage(const char * program) {
    printf("Usage : %s nom_fichier\n\n", program);
    printf("Le programme ouvre un fichier dont le nom est nom_fichier, lit et affiche 10 entiers.\n\n");
    printf("Exemples d'utilisation:\n");
    printf("%s cx15.0.txt\n", program);
    exit(1);
}
