/* *******************************************************
 * Nom           : cx15.2.c
 * Rôle          : Lecture de 10 entiers depuis un fichier
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx15.2.c -o cx15.2
 * Usage         : ./cx15.2 cx15.0.txt
 * *******************************************************/

/* Enoncé:
 * que fait fscanf() quand il s'attend à un entier mais trouve le mot « bidon » à la place ? Comment tester ce cas de
 * figure ?
 */

/* Explications:
 * Si fscanf n'arrive pas à lire le nombre qui est attendu (parce que ce n'est pas un nombre), elle va retourner 0
 * (0 éléments lus). On peut donc tester cette condition et afficher une erreur dans ce cas.
 */

#include <stdio.h>
#include <stdlib.h>

// Prototype
void usage(const char * program);
int read_display_integers(FILE *file);

int main(int k, char * ldc[]) {
    if(k != 2) usage(ldc[0]); // On attend 1 argument (en plus du nom du programme)

    FILE * file = fopen(ldc[1], "r") ;
    if(!file) { printf("Le fichier '%s' n'a pas pu être ouvert en lecture.\n\n", ldc[1]); usage(ldc[0]); }
    int nb = read_display_integers(file);
    printf("\n%d éléments ont été lus et affichés\n", nb);
    fclose(file);
    return 0;
}

int read_display_integers(FILE *file) {
    int max, x, lu = 0, nombres[10]; // Correction du bug avec l'initialisation de lu
    // Lecture des nombres dans le fichier, maximum 10 nombres
    for(max = 0; max < 10 && lu != EOF; max++) {
        lu = fscanf(file, "%d", &nombres[max]);
        // Si le nombre n'a pas pu être lu, on affiche un message et on sort de la fonction.
        if(!lu) { printf("L'élément %d n'a pas pu être lu.\n", max); return 0; }
    }
    // Si on n'a pas pu lire tous les nombres, max a une unité de trop (car on a essayé de lire le nombre)
    // donc on le décrémente de 1. Mais seulement dans ce cas-là. Si tous les nombres ont été lus, max a la bonne valeur.
    if(lu == EOF)
        --max;
    // On affiche les nombre
    for(x = 0; x < max; x++)
        printf("%i ", nombres[x]);
    // On retourne max, le nombre d'éléments effectivement lus.
    return max;
}

// Explique comment utiliser le programme
void usage(const char * program) {
    printf("Usage : %s nom_fichier\n\n", program);
    printf("Le programme ouvre un fichier dont le nom est nom_fichier, lit et affiche 10 entiers.\n\n");
    printf("Exemples d'utilisation:\n");
    printf("%s cx15.0.txt\n", program);
    exit(1);
}
