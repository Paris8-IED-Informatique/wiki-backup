/* *******************************************************
 * Nom           : cx15.4.c
 * Rôle          : Lecture de mots depuis un fichier
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx15.4.c -o cx15.4
 * Usage         : ./cx15.4 cx15.4.data
 * *******************************************************/

/* Enoncé:
 * ajouter les mots Rantanplan et Lucky Luke: modifier, aussi économiquement que possible, le programme [cx15.3]
 * pour accommoder les données supplémentaires.
 */

/* Explications:
 * Pour être plus générique, on va déclarer une constante NB_WORDS_MAX au début avec le nombre de mots (7) et remplacer
 * toutes les valeurs "en dur" par cette valeur ou calculé par rapport à cette valeur.
 * A noter que ce programme comporte un bug: la mémoire allouée par les différents appels à strdup n'est jamais rendue
 * au système. On a une fuite mémoire. Pour être totalement correcte, on devrait parcourir tout le tableau et appeler
 * free pour chaque élément non NULL.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NB_WORDS_MAX 7 // Nombre maximum de mots à lire

// Prototype
void usage(const char * program);
void read_strings(FILE *file, char * mots[NB_WORDS_MAX+1]);

int main(int k, char * ldc[]) {
    if(k != 2) usage(ldc[0]); // On attend 1 argument (en plus du nom du programme)

    char * mots[NB_WORDS_MAX+1]; // vecteur de NB_WORDS_MAX mots + élément NULL

    FILE * file = fopen(ldc[1], "r"); // ouverture du fichier en lecture
    if(!file) { printf("Le fichier '%s' n'a pas pu être ouvert en lecture.\n\n", ldc[1]); usage(ldc[0]); }
    read_strings(file, mots); // lecture des mots
    fclose(file); // fermeture du fichier

    // Attention: fuite de mémoire (mémoire allouée par strdup)

    return 0;
}

void read_strings(FILE *file, char * mots[NB_WORDS_MAX+1]) {
    int lu, max; // caractères lus, compteur
    for(max = 0; max < NB_WORDS_MAX; ++max) { // lit NB_WORDS_MAX mots
        char sas[32]; // buffer : le plus long mot français fait 25
        lu = fscanf(file, "%s", sas); // met le mot dans le sas
        mots[max] = strdup(sas); // recopie-le ailleurs
    }

    // On termine le tableau par un élément NULL
    mots[max] = NULL;
}


// Explique comment utiliser le programme
void usage(const char * program) {
    printf("Usage : %s nom_fichier\n\n", program);
    printf("Le programme ouvre un fichier dont le nom est nom_fichier et lit 3 mots.\n\n");
    printf("Exemples d'utilisation:\n");
    printf("%s cx15.4.data\n", program);
    exit(1);
}
