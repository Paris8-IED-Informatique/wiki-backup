/* *******************************************************
 * Nom           : cx08.5.c
 * Rôle          : size_x de tous les arguments
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx08.5.c -o cx08.5
 * Usage         : ./cx08.5 ABCDEF abc 1234
 * *******************************************************/

/* Enoncé:
 * coder un programme qui utilise la fonction size_x() pour afficher le nombre de caractères de chacun des mots de la
 * ligne de commande, quelqu'en soit le nombre.
 */

/* Explications:
 * On procède exactement comme dans le programme cx08.2:
 * On utilise une boucle while comme vu dans les exercices précédents et on appelle scan_x pour chaque argument (sauf
 * le premier qui est le nom du programme).
 */

#include <stdio.h>

unsigned int size_x(const char *); // Prototype (ajusté avec const)


int main(int k, const char *args[]) {
    int i = 1;  // On commence à partir du deuxième argument (indice 1)
    while(i < k)  // Tant que l'on a pas traité tous les arguments...
        printf("%u\n", size_x(args[i++])); // On appelle size_x avec l'argument, on incrémente l'indice et on affiche
    return 0;
}

unsigned int size_x (const char *str) {
    // Sur le même modèle que scan_x, mais on remplace int par unsigned int
    unsigned int k = 0; while(str[k]) k++; // Tant que l'on est pas arrivé à la fin de la chaine, on incrémente k
    return k; // On est arrivé à la fin de la chaine, on peut retourner k, le nombre de caractères
}
