/* *******************************************************
 * Nom           : cx08.4.c
 * Rôle          : size_x dans un programme
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx08.4.c -o cx08.4
 * Usage         : ./cx08.4 ABCDEF
 * *******************************************************/

/* Enoncé:
 * coder un programme qui utilise la fonction size_x() ci-dessus pour afficher le nombre de caractères du deuxième mot
 * de la ligne de commande – en supposant évidemment que le programme soit appelé avec au moins un argument...
 */

/* Explications:
 * On passe le deuxième argument de main (d'indice 1) à size_x et on affiche le résultat avec printf. Comme le résultat
 * est un unsigned int, on utilise %u plutot que %d.
 */

#include <stdio.h>

unsigned int size_x(const char *); // Prototype (ajusté avec const)


int main(int k, const char *args[]) {
    printf("%u\n", size_x(args[1])); // Deuxième argument, indice 1 et on affiche le résultat avec printf
    return 0;
}

unsigned int size_x(const char *str) {
    // Sur le même modèle que scan_x, mais on remplace int par unsigned int
    unsigned int k = 0; while(str[k]) k++; // Tant que l'on est pas arrivé à la fin de la chaine, on incrémente k
    return k; // On est arrivé à la fin de la chaine, on peut retourner k, le nombre de caractères
}
