/* *******************************************************
 * Nom           : cx08.1.c
 * Rôle          : scan_x dans un programme
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx08.1.c -o cx08.1
 * Usage         : ./cx08.1 ABCDEF
 * *******************************************************/

/* Enoncé:
 * coder un programme qui utilise la fonction scan_x() ci-dessus pour lister les caractères du deuxième mot de la ligne
 * de commande – en supposant évidemment que le programme soit appelé avec au moins un argument quelconque...
 */

/* Explications:
 * On passe le deuxième argument de main (d'indice 1) à scan_x.
 */

#include <stdio.h>

void scan_x(const char *); // Prototype (ajusté avec const)


int main(int k, const char *args[]) {
    scan_x(args[1]); // Deuxième argument, indice 1
    return 0;
}

void scan_x(const char *str) {
    // Exactement comme dans le cours, avec str à la place de mot
    int k = 0; while(str[k]) printf("%c\n", str[k++]);
}
