/* *******************************************************
 * Nom           : cx08.0.c
 * Rôle          : scan_x
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx08.0.c -o cx08.0
 * Usage         : scan_x("ABCDEF");
 * *******************************************************/

/* Enoncé:
 * coder la fonction scan_x() dont le prototype serait
 *   void scan_x(char *) ;
 *  et qui utiliserait l'accès indexé ci-dessus pour lister, afficher un par un, chacun sur une ligne, les éléments
 *  d'une chaîne quelconque passée en argument – et rien d'autre.
 */

/* Explications:
 * On implémente scan_x sur le modèle donné dans le cours.
 */

void scan_x(char *str) {
    // Exactement comme dans le cours, avec str à la place de mot
    int k = 0; while(str[k]) printf("%c\n", str[k++]);
}
