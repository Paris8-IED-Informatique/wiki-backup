/* *******************************************************
 * Nom           : cx08.3.c
 * Rôle          : size_x
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx08.3.c -o cx08.3
 * Usage         : size_x("ABCDEF");
 * *******************************************************/

/* Enoncé:
 * coder la fonction de prototype unsigned int size_x (char *), qui utiliserait l'accès indexé pour compter, puis
 * retourner le nombre effectifs de caractères dans une chaîne quelconque passée en argument.
 */

/* Explications:
 * On utilise le même modèle de fonction que scan_x mais on doit juste incrémenter l'indice k et on le retourne quand
 * on est arrivé à la fin de la chaine.
 */

unsigned int size_x(char *str) {
    // Sur le même modèle que scan_x, mais on remplace int par unsigned int
    unsigned int k = 0; while(str[k]) k++; // Tant que l'on est pas arrivé à la fin de la chaine, on incrémente k
    return k; // On est arrivé à la fin de la chaine, on peut retourner k, le nombre de caractères
}
