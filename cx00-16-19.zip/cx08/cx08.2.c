/* *******************************************************
 * Nom           : cx08.1.c
 * Rôle          : scan_x de tous les arguments
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx08.1.c -o cx08.1
 * Usage         : ./cx08.1 ABCDEF abcdef 123456
 * *******************************************************/

/* Enoncé:
 * coder un programme qui utilise la fonction scan_x() pour lister les caractères de chacun des mots de la ligne de
 * commande, quelqu'en soit le nombre.
 */

/* Explications:
 * On utilise une boucle while comme vu dans les exercices précédents et on appelle scan_x pour chaque argument (sauf
 * le premier qui est le nom du programme).
 */

#include <stdio.h>

void scan_x(const char *); // Prototype (ajusté avec const)


int main(int k, const char *args[]) {
    int i = 1;  // On commence à partir du deuxième argument (indice 1)
    while(i < k)  // Tant que l'on a pas traité tous les arguments...
        scan_x(args[i++]); // On appelle scan_x avec l'argument et on incrémente l'indice
    return 0;
}

void scan_x(const char *str) {
    // Exactement comme dans le cours, avec str à la place de mot
    int k = 0; while(str[k]) printf("%c\n", str[k++]);
}
