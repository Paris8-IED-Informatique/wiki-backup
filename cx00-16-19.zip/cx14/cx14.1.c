/* *******************************************************
 * Nom           : cx14.1.c
 * Rôle          : Lecture d'un fichier et écriture du contenu dans un autre
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx14.1.c -o cx14.1
 * Usage         : ./cx14.1 ../cx11/cx11.2.c texte
 * *******************************************************/

/* Enoncé:
 * compléter ce programme et l'essayer avec deux noms de fichier sur la ligne de commande (avec test sur le nombre
 * d'arguments); vérifier qu'il recopie bien le contenu du premier dans le deuxième. Le tester également en mettant
 * des noms invraisemblables, comme bip*bop!: voyez-vous l'intérêt d'afficher des messages d'erreurs détaillés?
 */

/* Explications:
 * On affiche un message d'erreur détaillé avec le nom du fichier en cas d'échec de fopen. Sans indiquer le nom du
 * fichier en question, l'utilisateur sera un peu perdu.
 */

#include <stdio.h>
#include <stdlib.h>

void usage(const char * program); // Prototype

int main(int k, char * ldc[]) {
    if(k != 3) usage(ldc[0]); // On attend 2 arguments (en plus du nom du programme)

    signed char x;
    FILE * R = fopen(ldc[1], "r") ;
    if (! R) { printf("Le fichier '%s' n'a pas pu être ouvert en lecture.\n\n", ldc[1]); usage(ldc[0]); }
    FILE * W = fopen(ldc[2], "w") ;
    if (! W) { printf("Le fichier '%s' n'a pas pu être ouvert en écriture.\n\n", ldc[2]); usage(ldc[0]); }
    while ((x = fgetc(R)) != EOF) fputc(x, W) ;
    fclose(R);
    fclose(W);
    return 0;
}

// Explique comment utiliser le programme
void usage(const char * program) {
    printf("Usage : %s source destination\n\n", program);
    printf("Le programme lit le contenu d'un fichier dont le nom est source et écrit ce contenu dans le fichier "
           "destination.\n\n");
    printf("Exemples d'utilisation:\n");
    printf("%s ../cx11/cx11.2.c text\n", program);
    exit(1);
}
