/* *******************************************************
 * Nom           : cx14.0.c
 * Rôle          : Lecture et affichage d'un fichier
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx14.0.c -o cx14.0
 * Usage         : ./cx14.0 ../cx11/cx11.2.c
 * *******************************************************/

/* Enoncé:
 * coder ce programme et le tester avec un nom de fichier sur la ligne de commande!; vérifier qu'il affiche bien le
 * contenu de ce fichier.
 */

/* Explications:
 * On ajoute simplement #include <stdio.h> pour avoir le prototype de fopen, fgetc, fputc, fclose et la définition de
 * stdout.
 */

#include <stdio.h>
#include <stdlib.h>

void usage(const char * program); // Prototype

int main(int k, char * ldc[]) {
    if(k != 2) usage(ldc[0]); // On attend 1 seul argument (en plus du nom du programme)

    signed char x;
    FILE * R = fopen(ldc[1], "r");
    if (! R) { printf("Le fichier '%s' n'a pas pu être ouvert en lecture.\n\n", ldc[1]); usage(ldc[0]); }
    while ((x = fgetc(R)) != EOF) fputc(x, stdout);
    fclose(R);
    return 0;
}

// Explique comment utiliser le programme
void usage(const char * program) {
    printf("Usage : %s nom_du_fichier\n\n", program);
    printf("Le programme affiche le contenu du fichier dont le nom est nom_du_fichier.\n\n");
    printf("Exemples d'utilisation:\n");
    printf("%s ../cx11/cx11.2.c\n", program);
    exit(1);
}
