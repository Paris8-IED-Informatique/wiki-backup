/* *******************************************************
 * Nom           : cx16.0.c
 * Rôle          : Lecture ligne par ligne
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx16.0.c -o cx16.0
 * Usage         : ./cx16.0 cx16.0.data
 * *******************************************************/

/* Enoncé:
 * coder ce programme et le tester avec tous les cas de figure possibles, en particulier celui d'un fichier
 * rigoureusement vide, d'un fichier non-terminé par un saut de ligne, et d'un fichier avec un paragraphe dépassant la
 * limite maximum. Essayer aussi de lire le code exécutable d'un programme!: que se passe-t-il s'il contient '\0',
 * un caractère nul ?
 */

/* Explications:
 * Le programme comporte un bug: en effet, si fgets rencontre un retout à la ligne, elle va retourner ce retour à la
 * ligne à la fin de ligne. Quand à fgets, elle affiche le contenu du paramètre suivi d'un retour à la ligne. Donc
 * on aura, pour chaque ligne, deux retours à la lignes. Une solution est de ne pas utiliser puts pour éviter ce retour
 * à la ligne supplémentaire (printf par exemple).
 *
 * Dans le cas d'un fichier rigoureusement vide (0 octets, généré avec: touch cx16.0-empty.data), fgets retourne NLL
 * et donc on entre pas dans la boucle. Donc le programme ne fait rien. C'est le résultat attendu.
 *
 * Dans le cas d'un fichier non-terminé par un saut de ligne (cx16.0-no-newline.data), fgets retourne le contenu tel
 * quel dans ligne (donc sans retour à la ligne) et puts affiche ce contenu avec un retour à la ligne.
 *
 * Dans le cas d'un fichier avec un paragraphe dépassant la limite maximum, fgets va lire uniquement le nombre
 * maximum de caractères qu'on lui a indiqué. Puis, lors de la prochaine itération, fgets va reprendre là oû elle en
 * était et va lire la suite du paragraphe. Mais là encore, l'utilisation de puts pose problème car elle va introduire
 * des retours à la ligne qui n'existe pas dans le fichier d'origine.
 */

#include <stdio.h>
#include <stdlib.h>

#define maximum 4096

// Prototype
void usage(const char * message);


int main(int k, char * ldc[]) {
    if(k < 2) usage("manque le nom du fichier");
    char ligne[maximum];
    FILE * flux = fopen(ldc[1], "r");
    if (! flux) usage("Echec lors de l'ouverture du fichier en lecture");
    while (fgets(ligne, maximum, flux)) puts(ligne);
    fclose(flux);
    return 0; 
}

// Explique comment utiliser le programme
void usage(const char * message) {
    printf("%s\n\n", message);
    printf("Usage : cx16.0 nom_fichier\n\n");
    printf("Le programme ouvre un fichier dont le nom est nom_fichier et l'écrit sur la sortie, ligne par ligne.\n\n");
    printf("Exemples d'utilisation:\n");
    printf("cx16.0 cx16.0.c\n");
    exit(1);
}
