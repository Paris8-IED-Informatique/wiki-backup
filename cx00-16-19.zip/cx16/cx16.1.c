/* *******************************************************
 * Nom           : cx16.1.c
 * Rôle          : Ecriture d'un fichier
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx16.1.c -o cx16.1
 * Usage         : ./cx16.1 test
 * *******************************************************/

/* Enoncé:
 * essayer ce programme en mettant, sur la ligne de commande, des mots entre guillemets ou entre parenthèses; par
 * exemple "allez, zou !", ou (b^2 - 4*a*c), ou encore "(1 2 3) soleil". Comment le programme traite-t-il ces
 * expressions ? Est-ce bien le nom de fichier attendu ?
 */

/* Explications:
 *
 */

#include <stdio.h>
#include <stdlib.h>

void usage(char *); // prototype

int main(int k, char * ldc[])
{  if (k < 2) usage("au moins un argument"); // évidemment
    FILE * flux = fopen(ldc[1], "w"); // ouvre ldc [1] en mode write
    if (!flux) usage("fichier pas bon"); // garde-fou
    while (*ldc) fprintf(flux, "%s\n", *ldc++);
    fclose(flux);
    return 0;
}

void usage(char * message) { fprintf(stderr, "%s\n", message); exit(1); }
