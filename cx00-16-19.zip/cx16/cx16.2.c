/* *******************************************************
 * Nom           : cx16.2.c
 * Rôle          : Ecriture d'un fichier
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx16.2.c -o cx16.2
 * Usage         : ./cx16.2
 * *******************************************************/

/* Enoncé:
 * essayer ce programme en donnant à la variable P la valeur de votre choix!; rediriger la sortie (depuis la ligne de
 * commande) vers un fichier que vous tenterez d'interpréter de l'intérieur de votre programme C en utilisant la fonction system().
 */

/* Explications:
 *
 */

#include <stdio.h>

int main (void) {
    char * H = "CAB", * N = "123";
    int n1, n2;
    sscanf(H, "%x", & n1);
    sscanf(N, "%i", & n2);
    char P[] = "for x in range(%i): print x * %i";
    char R[128];
    sprintf(R, P, n1, n2);
    printf("%s\n", R);
    return 0; 
}
