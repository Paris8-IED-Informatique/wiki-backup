/* *******************************************************
 * Nom           : cx09.5.c
 * Rôle          : size_r de tous les arguments
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx09.5.c -o cx09.5
 * Usage         : ./cx09.5 ABCDEF abc 1234
 * *******************************************************/

/* Enoncé:
 * modifier le programme [cx08.5] pour qu'il utilise la fonction size_r() pour faire pareil.
 */

/* Explications:
 * On remplace size_x par size_r.
 */

#include <stdio.h>

unsigned int size_r(const char *); // Prototype (ajusté avec const)


int main(int k, const char *args[]) {
    int i = 1;  // On commence à partir du deuxième argument (indice 1)
    while(i < k)  // Tant que l'on a pas traité tous les arguments...
        printf("%u\n", size_r(args[i++])); // On appelle size_x avec l'argument, on incrémente l'indice et on affiche
    return 0;
}

unsigned int size_r(const char *str) {
    // On garde l'adresse du début de la chaine
    const char *begin = str; while(*str) str++; // Tant que l'on n'est pas arrivé à la fin de la chaine, on incrémente str
    return str - begin; // Le nombre de caractères est la différence entre la fin (le 0 terminal) et le début de la chaine.
}
