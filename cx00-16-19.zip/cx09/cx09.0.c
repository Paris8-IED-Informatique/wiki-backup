/* *******************************************************
 * Nom           : cx09.0.c
 * Rôle          : scan_r
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx09.0.c -o cx09.0
 * Usage         : scan_x("ABCDEF");
 * *******************************************************/

/* Enoncé:
 * coder la fonction de prototype void scan_r (char *), qui utiliserait le mécanisme d'accès par référence pour lister
 * (afficher un par un, chacun sur une ligne) les éléments d'une chaîne quelconque passée en argument – et rien
 * d'autre...
 */

/* Explications:
 * On implémente scan_r sur le modèle donné dans le cours.
 */

void scan_r(char *str) {
    // Exactement comme dans le cours, avec str à la place de mot
    while (*str) printf("%c\n", *str++);
}
