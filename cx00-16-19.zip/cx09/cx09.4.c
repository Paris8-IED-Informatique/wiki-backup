/* *******************************************************
 * Nom           : cx09.4.c
 * Rôle          : size_r dans un programme
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx09.4.c -o cx09.4
 * Usage         : ./cx09.4 ABCDEF
 * *******************************************************/

/* Enoncé:
 * modifier le programme [cx08.4] pour qu'il utilise la fonction size_r() et non size_x().
 */

/* Explications:
 * On remplace size_x par size_r.
 */

#include <stdio.h>

unsigned int size_r(const char *); // Prototype (ajusté avec const)


int main(int k, const char *args[]) {
    printf("%u\n", size_r(args[1])); // Deuxième argument, indice 1 et on affiche le résultat avec printf
    return 0;
}

unsigned int size_r(const char *str) {
    // On garde l'adresse du début de la chaine
    const char *begin = str; while(*str) str++; // Tant que l'on n'est pas arrivé à la fin de la chaine, on incrémente str
    return str - begin; // Le nombre de caractères est la différence entre la fin (le 0 terminal) et le début de la chaine.
}
