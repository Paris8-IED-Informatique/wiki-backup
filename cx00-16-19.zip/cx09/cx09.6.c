/* *******************************************************
 * Nom           : cx09.6.c
 * Rôle          : size_r de tous les arguments + usage
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx09.6.c -o cx09.6
 * Usage         : ./cx09.6 ABCDEF abc 1234
 * *******************************************************/

/* Enoncé:
 * recoder le programme [cx09.5] pour qu'il arrête son exécution en affichant un gros message d'usage bien explicite
 * si on l'appelle sans aucun argument.
 */

/* Explications:
 * On ajoute la fonction usage qui affiche un message assez complet pour indiquer comment utiliser le programme.
 */

#include <stdio.h>
#include <stdlib.h>

void usage(const char *); // Prototype (ajusté avec const)
unsigned int size_r(const char *); // Prototype (ajusté avec const)


int main(int k, const char *args[]) {
    if(k < 2) usage(*args);

    int i = 1;  // On commence à partir du deuxième argument (indice 1)
    while(i < k)  // Tant que l'on a pas traité tous les arguments...
        printf("%u\n", size_r(args[i++])); // On appelle size_x avec l'argument, on incrémente l'indice et on affiche
    return 0;
}

unsigned int size_r(const char *str) {
    // On garde l'adresse du début de la chaine
    const char *begin = str; while(*str) str++; // Tant que l'on n'est pas arrivé à la fin de la chaine, on incrémente str
    return str - begin; // Le nombre de caractères est la différence entre la fin (le 0 terminal) et le début de la chaine.
}

void usage(const char * program) {
    printf("Compte le nombre de caractères de chaque argument.\n\n");
    printf("Usage : %s <argument1> ... <argumentn>\n\n", program);
    printf("Il est possible de spécifier 1 ou plusieurs arguments. Le programme indique le nombre de caractères de "
           "chaque argument, un par ligne.\n\n");
    printf("Exemples d'utilisation:\n");
    printf("%s ABCDEF\n", program);
    printf("%s ABCDEF abcd 123\n", program);
    exit(1);
}
