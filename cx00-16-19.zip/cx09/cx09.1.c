/* *******************************************************
 * Nom           : cx09.1.c
 * Rôle          : scan_r dans un programme
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx09.1.c -o cx09.1
 * Usage         : ./cx09.1 ABCDEF
 * *******************************************************/

/* Enoncé:
 * modifier le programme [cx08.1] de sorte qu'au lieu de scan_x(), il utilise scan_r() pour lister les caractères du
 * deuxième mot de la ligne de commande.
 */

/* Explications:
 * On remplace scan_x par scan_r.
 */

#include <stdio.h>

void scan_r(const char *); // Prototype (ajusté avec const)


int main(int k, const char *args[]) {
    scan_r(args[1]); // Deuxième argument, indice 1
    return 0;
}

void scan_r(const char *str) {
    // Exactement comme dans le cours, avec str à la place de mot
    while (*str) printf("%c\n", *str++);
}
