/* *******************************************************
 * Nom           : cx09.2.c
 * Rôle          : scan_r de tous les arguments
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx09.2.c -o cx09.2
 * Usage         : ./cx09.2 ABCDEF abcdef 123456
 * *******************************************************/

/* Enoncé:
 * modifier le programme [cx08.2] de sorte qu'il utilise scan_r() pour lister les caractères de chacun des mots de la
 * ligne de commande.
 */

/* Explications:
 * On remplace scan_x par scan_r.
 */

#include <stdio.h>

void scan_r(const char *); // Prototype (ajusté avec const)


int main(int k, const char *args[]) {
    int i = 1;  // On commence à partir du deuxième argument (indice 1)
    while(i < k)  // Tant que l'on n'a pas traité tous les arguments...
        scan_r(args[i++]); // On appelle scan_r avec l'argument et on incrémente l'indice
    return 0;
}

void scan_r(const char *str) {
    // Exactement comme dans le cours, avec str à la place de mot
    while (*str) printf("%c\n", *str++);
}
