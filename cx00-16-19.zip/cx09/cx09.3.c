/* *******************************************************
 * Nom           : cx09.3.c
 * Rôle          : size_r
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx09.3.c -o cx09.3
 * Usage         : size_x("ABCDEF");
 * *******************************************************/

/* Enoncé:
 * coder la fonction de prototype unsigned size_r (char *), qui compte – en utilisant le mécanisme d'accès par
 * référence – le nombre effectif de caractères dans la chaîne passée en argument, et retourne cette valeur.
 */

/* Explications:
 * On incrémente str, le pointeur de la chaine, tant que l'on n'est pas arrivé au 0 terminal (qui est juste après la fin
 * de la chaine). Il suffit alors de retourner la différence entre ce pointeur et le début de la chaine.
 */

unsigned int size_r(char *str) {
    // On garde l'adresse du début de la chaine
    char *begin = str; while(*str) str++; // Tant que l'on n'est pas arrivé à la fin de la chaine, on incrémente str
    return str - begin; // Le nombre de caractères est la différence entre la fin (le 0 terminal) et le début de la chaine.
}
