/* *******************************************************
 * Nom           : cx011.1.c
 * Rôle          : Eviter d'afficher l'option
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx011.1.c -o cx011.1
 * Usage         : ./cx011.1 -i de test
 * *******************************************************/

/* Enoncé:
 * imaginer un moyen d'afficher les arguments sans faire apparaître l'option elle-même.
 */

/* Explications:
 * Un moyen simple est de tenir compte du fait que l'option n'apparait que comme premier argument et dans ce cas, on
 * appelle envers. Il suffit qu'envers n'affiche pas cet argument. On le gère avec un if dans la boucle pour teste
 * l'indice. La réponse à l'exercice suivant montre une autre manière plus générique de répondre à cette même quesion.
 */

#include <stdio.h>
#include <stdlib.h>

// Prototypes
void usage(const char * program);
int option_i(const char *mot); // Ajout de const pour être cohérent
void endroit(int k, const char* ldc[]);
void envers(int k, const char* ldc[]);

int main(int max, const char *ldc[]) {
    // Est-ce que l'on a bien un argument (en plus du nom du programme) ?
    if(max < 2) usage(ldc[0]); // non: on affiche un message et on sort

    // Pas besoin d'une variable locale intermédiaire
    if(option_i(ldc[1])) // Si l'option est présente...
        envers(max, ldc); // on affiche à l'envers
    else
        endroit(max, ldc); // Sinon à l'endroit

    return 0;
}

// Comme dans l'exercice cx02.3
// Affiche les éléments de ldc à l'endroit
void endroit(int max, const char* ldc[]) { int k = 0; while(k < max) puts(ldc[k++]); }

// Comme dans l'exercice cx02.2
// Affiche les éléments de ldc à l'envers
// On n'affiche pas l'argument 1 (k == 2)
void envers(int k, const char* ldc[]) { while(k) if(k != 2) puts(ldc[--k]); else --k; }

// On teste si on a "-i"
int option_i(const char *mot) { return mot[0] == '-' && mot[1] == 'i'; }

// Explique comment utiliser le programme
void usage(const char * program) {
    printf("Affiche les arguments à l'endroit ou à l'envers.\n\n");
    printf("Usage : %s [-i] arg1 ... argn\n\n", program);
    printf("Il est possible de spécifier 1 ou plusieurs arguments. Le programme affiche les paramètres soit à l'endroit "
           "(sans option), soit à l'envers (avec l'option -i).\n\n");
    printf("Exemples d'utilisation:\n");
    printf("%s ABCDEF\n", program);
    printf("%s -i ABCDEF abcd 123\n", program);
    exit(1);
}
