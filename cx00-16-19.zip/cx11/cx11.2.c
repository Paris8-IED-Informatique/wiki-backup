/* *******************************************************
 * Nom           : cx011.2.c
 * Rôle          : Eviter d'afficher l'option à n'importe quelle position
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx011.2.c -o cx011.2
 * Usage         : ./cx011.2 -i de test
 * *******************************************************/

/* Enoncé:
 * recoder le programme précédent pour qu'il détecte l'option -i n'importe où parmi les arguments, quelque soit leur
 * nombre. Le tester, par exemple avec:
 *
*    programme -bidon 2 -trucs -idiots qui marchent
 */

/* Explications:
 * On applique les instructions du cours. Notre moyen précédent pour éviter d'afficher l'option ne marche plus car
 * l'option peut apparaître n'importe où (et même plusieurs fois). Donc à la place du teste de l'indice, nous allons
 * utiliser option_i pour savoir si on peut afficher ou non l'argument.
 */

#include <stdio.h>
#include <stdlib.h>

// Prototypes
void usage(const char * program);
int option_i(const char *mot); // Ajout de const pour être cohérent
void endroit(int k, const char* ldc[]);
void envers(int k, const char* ldc[]);

int main(int max, const char *ldc[]) {
    // Est-ce que l'on a bien un argument (en plus du nom du programme) ?
    if(max < 2) usage(ldc[0]); // non: on affiche un message et on sort

    int inverse = 0 ; // initialisé à faux
    int k = 0 ;
    while(k < max) // max est le 1er paramètre de main()
        if(option_i(ldc[k++])) inverse = 1;

    // Pas besoin d'une variable locale intermédiaire
    if(inverse) // Si l'option est présente...
        envers(max, ldc); // on affiche à l'envers
    else
        endroit(max, ldc); // Sinon à l'endroit

    return 0;
}

// Comme dans l'exercice cx02.3
// Affiche les éléments de ldc à l'endroit
void endroit(int max, const char* ldc[]) { int k = 0; while(k < max) puts(ldc[k++]); }

// Comme dans l'exercice cx02.2
// Affiche les éléments de ldc à l'envers
// On n'affiche pas l'argument si c'est notre option. On déplace la pré-décrémentation dans notre if.
void envers(int k, const char* ldc[]) { while(k) if(!option_i(ldc[--k])) puts(ldc[k]); }

// On teste si on a "-i"
int option_i(const char *mot) { return mot[0] == '-' && mot[1] == 'i'; }

// Explique comment utiliser le programme
void usage(const char * program) {
    printf("Affiche les arguments à l'endroit ou à l'envers.\n\n");
    printf("Usage : %s [-i] arg1 ... argn\n\n", program);
    printf("Il est possible de spécifier 1 ou plusieurs arguments. Le programme affiche les paramètres soit à l'endroit "
           "(sans option), soit à l'envers (avec l'option -i).\n\n");
    printf("Exemples d'utilisation:\n");
    printf("%s ABCDEF\n", program);
    printf("%s -i ABCDEF abcd 123\n", program);
    printf("%s -bidon 2 -trucs -idiots qui marchent\n", program);
    exit(1);
}
