/* *******************************************************
 * Nom           : cx11.0.c
 * Rôle          : Prise en compte d'une option
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx11.0.c -o cx11.0
 * Usage         : ./cx11.0 -i de test
 * *******************************************************/

/* Enoncé:
 * coder le programme complet, de sorte que s'il n'y a pas d'option -i en deuxième argument sur la LdC, l'affichage est
 * normal, et s'il y en a une, l'affichage est inversé; tester aussi ce programme avec de fausses options, comme
 * -bidon ou -truc, qui ne devraient normalement pas influer sur l'affichage.
 */

/* Explications:
 * On reprend le code des exercices cx02.2 (à l'envers) et cx02.3 (à l'endroit). Pour être plus explicite, on met
 * ce code dans deux fonctions: endroit et envers. On teste si l'option -i est présente avec option_i. Si c'est le cas
 * on appelle envers. Sinon endroit.
 *
 * En l'état, le programme comporte certains bugs:
 * - Si on ne donne aucun argument, il plante (car on accède à lcd[1] qui n'existe pas). On va tester le nombre
 * d'arugment pour éviter ce problème.
 * - Si on donne un argument comme -ii ou -image, le programme va se comporter comme si l'option était -i (ce point est
 * le sujet de l'exercice cx11.3)
 * - L'option elle-même est affichée (ce point est le sujet de l'exercice suivant)
 */

#include <stdio.h>
#include <stdlib.h>

// Prototypes
void usage(const char * program);
int option_i(const char *mot); // Ajout de const pour être cohérent
void endroit(int k, const char* ldc[]);
void envers(int k, const char* ldc[]);

int main(int max, const char *ldc[]) {
    // Est-ce que l'on a bien un argument (en plus du nom du programme) ?
    if(max < 2) usage(ldc[0]); // non: on affiche un message et on sort

    // Pas besoin d'une variable locale intermédiaire
    if(option_i(ldc[1])) // Si l'option est présente...
        envers(max, ldc); // on affiche à l'envers
    else
        endroit(max, ldc); // Sinon à l'endroit

    return 0;
}

// Comme dans l'exercice cx02.3
// Affiche les éléments de ldc à l'endroit
void endroit(int max, const char* ldc[]) { int k = 0; while(k < max) puts(ldc[k++]); }

// Comme dans l'exercice cx02.2
// Affiche les éléments de ldc à l'envers
void envers(int k, const char* ldc[]) { while(k) puts(ldc[--k]); }

// On teste si on a "-i"
int option_i(const char *mot) { return mot[0] == '-' && mot[1] == 'i'; }

// Explique comment utiliser le programme
void usage(const char * program) {
    printf("Affiche les arguments à l'endroit ou à l'envers.\n\n");
    printf("Usage : %s [-i] arg1 ... argn\n\n", program);
    printf("Il est possible de spécifier 1 ou plusieurs arguments. Le programme affiche les paramètres soit à l'endroit "
           "(sans option), soit à l'envers (avec l'option -i).\n\n");
    printf("Exemples d'utilisation:\n");
    printf("%s ABCDEF\n", program);
    printf("%s -i ABCDEF abcd 123\n", program);
    exit(1);
}
