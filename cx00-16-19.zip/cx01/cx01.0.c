/* *******************************************************
 * Nom           : cx01.0.c
 * Rôle          : Afficher un poème, variable globale
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx01.0.c -o cx01.0
 * Usage         : ./cx01.0
 * *******************************************************/

/* Enoncé:
 * coder et compiler le programme, après y avoir substitué votre propre poème comme valeur de la variable texte (comme
 * proposé au cx00.3) ; vérifier que tout se déroule comme prévu. */

/* Explications:
 * L'éphéméride de Ombrage Lafanelle, https://short-edition.com/fr/oeuvre/poetik/lephemeride */


#include <stdio.h> // pour puts()

#define str char * // directive de substitution

str texte[] = {
    "haiku :",
    "Matin d'hiver",
    "sur une carotte en guise de nez",
    "un éphémère se pose",
    "",
    "Matin printanier",
    "une main verte et ridée",
    "un jardinier peu pressé",
    "",
    "Matin d'été",
    "deux vieilles branches se saluent",
    "l'un est chêne, l'autre est figuier",
    "",
    "Matin d'automne",
    "sur un arbre centenaire",
    "une palette de couleurs"
};

int main() {
    puts(texte[0]);
    puts(texte[1]);
    puts(texte[2]);
    puts(texte[3]);
    puts(texte[4]);
    puts(texte[5]);
    puts(texte[6]);
    puts(texte[7]);
    puts(texte[8]);
    puts(texte[9]);
    puts(texte[10]);
    puts(texte[11]);
    puts(texte[12]);
    puts(texte[13]);
    puts(texte[14]);
    puts(texte[15]);
    return 0;
}
