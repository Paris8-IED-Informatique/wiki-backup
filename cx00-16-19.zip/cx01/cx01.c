#include <stdio.h> // pour puts()

#define str char * // directive de substitution

str texte[] = {"haiku :", "l'arbre que j'abats,", "comme il est calme..."} ;

int main()
{  puts(texte[0]) ;
    puts(texte[1]) ;
    puts(texte[2]) ;
    return 0 ; }
