/* *******************************************************
 * Nom           : cx01.1.c
 * Rôle          : Afficher un poème, variable locale
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx01.1.c -o cx01.1
 * Usage         : ./cx01.1
 * *******************************************************/

/* Enoncé:
 * coder et compiler cette variante du programme ; vérifier que son affichage est bien le même que celui de l'exercice
 * précédent */


#include <stdio.h> // pour puts()

#define str char * // directive de substitution

int main() {
    str texte[] = {
        "haiku :",
        "Matin d'hiver",
        "sur une carotte en guise de nez",
        "un éphémère se pose",
        "",
        "Matin printanier",
        "une main verte et ridée",
        "un jardinier peu pressé",
        "",
        "Matin d'été",
        "deux vieilles branches se saluent",
        "l'un est chêne, l'autre est figuier",
        "",
        "Matin d'automne",
        "sur un arbre centenaire",
        "une palette de couleurs"
    };

    puts(texte[0]);
    puts(texte[1]);
    puts(texte[2]);
    puts(texte[3]);
    puts(texte[4]);
    puts(texte[5]);
    puts(texte[6]);
    puts(texte[7]);
    puts(texte[8]);
    puts(texte[9]);
    puts(texte[10]);
    puts(texte[11]);
    puts(texte[12]);
    puts(texte[13]);
    puts(texte[14]);
    puts(texte[15]);
    return 0;
}
