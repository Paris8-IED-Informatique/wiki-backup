/* *******************************************************
 * Nom           : cx01.2.c
 * Rôle          : Afficher un poème, avec while
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx01.2.c -o cx01.2
 * Usage         : ./cx01.2
 * *******************************************************/

/* Enoncé:
 * rédiger et compiler le code ci-dessus en y incluant votre propre poème ; vérifier que le programme affiche exactement
 * la même chose que les deux exercices précédents. */

/* Explications:
 * On doit ajuster la limite (3 dans le programme du cours) pour correspondre à la taille du tableau. */

#include <stdio.h> // pour puts()

#define str char * // directive de substitution

str texte[] = {
    "haiku :",
    "Matin d'hiver",
    "sur une carotte en guise de nez",
    "un éphémère se pose",
    "",
    "Matin printanier",
    "une main verte et ridée",
    "un jardinier peu pressé",
    "",
    "Matin d'été",
    "deux vieilles branches se saluent",
    "l'un est chêne, l'autre est figuier",
    "",
    "Matin d'automne",
    "sur un arbre centenaire",
    "une palette de couleurs"
};

int main() {
    int k = 0;
    while (k < 16) puts(texte[k++]); // On ajuste la limite à la longueur du tableau (16)
    return 0;
}
