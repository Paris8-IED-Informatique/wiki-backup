/* *******************************************************
 * Nom           : cx01.3.c
 * Rôle          : Afficher un poème, à l'envers
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx01.3.c -o cx01.3
 * Usage         : ./cx01.3
 * *******************************************************/

/* Enoncé:
 * modifier ainsi la fonction main() de l'exercice précédent pour réciter votre poème à l'envers. */

/* Explications:
 * On doit ajuster la valeur initiale de k pour correspondre à la taille du tableau - 1. */

#include <stdio.h> // pour puts()

#define str char * // directive de substitution

str texte[] = {
    "haiku :",
    "Matin d'hiver",
    "sur une carotte en guise de nez",
    "un éphémère se pose",
    "",
    "Matin printanier",
    "une main verte et ridée",
    "un jardinier peu pressé",
    "",
    "Matin d'été",
    "deux vieilles branches se saluent",
    "l'un est chêne, l'autre est figuier",
    "",
    "Matin d'automne",
    "sur un arbre centenaire",
    "une palette de couleurs"
};

int main() {
    int k = 15; // On ajuste pour correspondre à la taille du tableau - 1 (16 - 1 = 15)
    while (k) puts(texte[k--]);
    return 0;
}