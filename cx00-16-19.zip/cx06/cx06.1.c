/* *******************************************************
 * Nom           : cx06.1.c
 * Rôle          : Codage ASCII étendu
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx06.1.c -o cx06.1
 * Usage         : ./cx06.1
 * *******************************************************/

/* Enoncé:
 * modifier le programme [cx06.0] pour que l'argument 2 à l'appel de la fonction ascii(), soit 256 au lieu de 128.
 * Est-ce une bonne ou une mauvaise surprise!?
 */

/* Explications:
 * Le résultat dépend de la configuration de la machine et plus particulièrement, de l'encodage configuré dans le shell.
 * - Si cet encodage en UTF-8 (comme c'est souvent le cas de nos jours), les caractères avec un codage entre 128 et 255
 * vont apparaitre comme points d'interrogation noirs sur plus ou moins un losange sur fond blanc.
 * En effet, le code est invalide en UTF-8 et donc le terminal affiche ce caractère Unicode spécial ("Replacement
 * character"): https://en.wikipedia.org/wiki/Specials_(Unicode_block)
 * - Si l'encodage est ISO-8859-1 et si la police de caractère le permet, certains caractères vont apparaitre en
 * particulier à partir de 161. On peut forcer l'encodage avec la command luit:
 *   luit -encoding ISO-8851-1 ./cx06.1
 *
 * Note: Il me semble qu'il y a une erreur dans l'énoncé: ce devrait être 127 et 255, pas 128 et 256.
 */

#include <stdio.h>

#define str char *

void ascii(int, int); // prototype

int main(void) { ascii(0, 256); return 0; }

void ascii(int ascii, int max) {
    while(ascii++ < max)
        printf("%i %c\n", ascii, ascii);
}
