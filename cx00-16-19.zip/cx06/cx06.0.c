/* *******************************************************
 * Nom           : cx06.0.c
 * Rôle          : Codage ASCII
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx06.0.c -o cx06.0
 * Usage         : ./cx06.0
 * *******************************************************/

/* Enoncé:
 * coder et compiler le programme ci-dessus (sans oublier d'inclure stdio.h)!; remarquez que la différence de codage
 * entre une lettre majuscule et une minuscule est une puissance de 2: que pouvez-vous en déduire?
 */

/* Explications:
 * Le codage des lettres majuscules commencent à 65 (A), le codage des lettres minuscules commencent à 97 (a).
 * Il y a donc une différence de 32 entre majuscules et minuscules. Au niveau binaire, cela veut qu'il n'y a qu'un bit
 * de différence entre les deux (le bit numéro 5).
 *   65 (A) => 0100 0001
 *   97 (a) => 0110 0001
 * En d'autres termes, pour passer de majuscule ou minuscule (et inversement), il suffit d'inverser le bit 5.
 *
 * Note: Il me semble qu'il y a une erreur dans le cours: ce devrait être 127, pas 128.
 */

#include <stdio.h>

#define str char *

void ascii(int, int); // prototype

int main(void) { ascii(0, 128); return 0; }

void ascii(int ascii, int max) {
    while(ascii++ < max)
        printf("%i %c\n", ascii, ascii);
}
