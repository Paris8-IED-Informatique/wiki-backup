/* *******************************************************
 * Nom           : cx02.0.c
 * Rôle          : Afficher le premier argument
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx02.0.c -o cx02.0
 * Usage         : ./cx02.0 quelques arguments
 * *******************************************************/

/* Enoncé:
 * rédiger le programme ci-dessus dans un fichier nommé, de préférence, cx02.0.c, et le compiler en utilisant votre
 * script comp (cf. [sx00]), ou bien par la commande:
   gcc -Wall cx02.0.c -o cx02.0*/


#include <stdio.h> // directive d'inclusion

#define str char * // directive de substitution

int main(int k, const str args[]) { puts(args[0]); return 0; } // code à exécuter