/* *******************************************************
 * Nom           : cx02.1.c
 * Rôle          : Afficher plusieurs arguments
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx02.1.c -o cx02.1
 * Usage         : ./cx02.1 fonctionne avec plusieurs arguments
 * *******************************************************/

/* Enoncé:
 * compiler et tester le code ci-dessus après avoir ajouté des instructions pour afficher aussi
les éléments 3 et 4: les mots « plusieurs » et « arguments ». */

/* Explications:
 * On duplique les lignes pour afficher les arguments 3 et 4. */


#include <stdio.h> // directive d'inclusion

#define str char * // directive de substitution

int main(int k, const str args[]) {
    puts(args[0]);
    puts(args[1]);
    puts(args[2]);
    puts(args[3]); // Argument 3
    puts(args[4]); // Argument 3
    return 0;
}