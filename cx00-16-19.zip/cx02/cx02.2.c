/* *******************************************************
 * Nom           : cx02.2.c
 * Rôle          : Afficher plusieurs arguments, à l'envers
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx02.2.c -o cx02.2
 * Usage         : ./cx02.2 fonctionne
 *               : ./cx02.2 fonctionne avec
 *               : ./cx02.2 fonctionne avec plusieurs arguments
 *               : ./cx02.2
 * *******************************************************/

/* Enoncé:
 * compiler et tester le code ci-dessus, avec 1, 2 ou n arguments sur la ligne de commande. */


#include <stdio.h> // directive d'inclusion

#define str char * // directive de substitution

int main(int k, const str ldc[]) { while (k) puts(ldc[--k]); return 0; }
