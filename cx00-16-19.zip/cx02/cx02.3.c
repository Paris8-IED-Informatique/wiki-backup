/* *******************************************************
 * Nom           : cx02.3.c
 * Rôle          : Afficher plusieurs argument, à l'endroit
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx02.3.c -o cx02.3
 * Usage         : ./cx02.3 fonctionne
 *               : ./cx02.3 fonctionne avec cinq arguments
 *               : ./cx02.3 se bouffe des arguments sur la ligne de commande
 *               : ./cx02.3
 * *******************************************************/

/* Enoncé:
 * ce programme affiche évidemment les arguments en partant du dernier. modifier le code pour les afficher dans l'ordre;
 * testez-le avec différents arguments, comme:
 * cx02.3 fonctionne
 * cx02.3 fonctionne avec cinq arguments
 * cx02.3 se bouffe des arguments sur la ligne de commande
 */

/* Explications:
 * Il y a plusieurs manières de faire. En s'inspirant du programme cx01.2, on crée une variable locale i qui va de
 * 0 à k (exclus) et on affiche l'argument correspondant. */


#include <stdio.h> // directive d'inclusion

#define str char * // directive de substitution

int main(int k, const str ldc[]) {
    int i = 0; // Notre indice pour les arguments
    while(i < k) puts(ldc[i++]); // On va jusqu'à k (exclus) et on affiche l'argument i; on incrémente i.
    return 0;
}
