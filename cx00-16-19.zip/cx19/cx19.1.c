/* *******************************************************
 * Nom           : cx19.1.c
 * Rôle          : Nombres romains
 * Auteur        : Sebastien Andrivet - 20013599
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx19.1.c -o cx19.1
 * Usage         : ./cx19.1 papa alpha zulu hotel charlie
 * *******************************************************/

/* Enoncé:
 * coder cette version et la tester depuis la ligne de commande avec les mêmes arguments que pour le prototype;
 * attention à inclure les fichiers d'en-tête, à définir une fonction usage() rudimentaire, et à vérifier que le
 * malloc() de conv n'a pas échoué.
 */

/* Explications:
 *
 */

#include <stdlib.h>
#include <string.h>
#include <printf.h>


struct {
    char R; // chiffre romain
    int D; // valeur en décimal
}
val[] = {
    {'C', 100},
    {'M', 1000},
    {'I', 1},
    {'V', 5},
    {'X', 10},
    {'L', 50},
    {'D', 500}
};


void usage(const char *message);
int indice(char c, int max);


int main(int argc, const char *argv[]) {
    if(argc < 2) usage("Il manque nombre en chiffres romains");
    const char *romain = argv[1];
    size_t taille = strlen(romain);
    int *conv = malloc(taille * sizeof(int));
    if(NULL == conv)
        usage("Une allocation mémoire a échouée");
    int i, dec, N = sizeof(val);
    for(argc = 0; argc < taille; ++argc) {
        i = indice(romain[argc], N);
        if(i < 0) usage("Chiffre romain inconnu");
        conv[argc] = val[i].D;
    }
    dec = 0;
    for(argc = 0; argc < taille - 1; ++argc) {
        if(conv[argc] < conv[argc + 1]) dec -= conv[argc];
        else dec += conv[argc];
    }
    dec += conv[argc];
    printf("%s = %i\n", argv[1], dec);
    free(conv);
    return 0;
}

int indice(char c, int max) {
    int i;
    for(i = 0 ; i < max ; ++i) if(toupper(c) == val[i].R) return i;
    return -1 ;
}


/**
 * Affiche un message d'erreur, indique comment utiliser le programme et termine l'exécution.
 *
 * @param message Le message à afficher.
 */
void usage(const char *message) {
    fprintf(stderr, "%s\n\n", message);
    fprintf(stderr, "Ce programme transforme un nombre en chiffre romain en écriture déicmale.\n\n");
    fprintf(stderr, "Usage:\n");
    fprintf(stderr, "cx19.1 CLIX\n\n");
    exit(1);
}
