/* *******************************************************
 * Nom           : cx05.3.c
 * Rôle          : Arguments de main
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx05.3.c -o cx05.3
 * Usage         : ./cx05.3 *.c
 * *******************************************************/

/* Enoncé:
 * coder un programme capable d'afficher les valeurs du 2e et du 3e paramètre; soigner la modularité!: main()
 * appellera putwords() d'abord avec argv, ensuite avec envp; tester ce programme en l'appelant avec une spécification
 * de fichiers comme, par exemple, *.c, et comparer le résultat affiché avec le contenu du directory courant, ainsi
 * qu'avec le résultat de la commande env.
 */

/* Explications:
 * Dans le cas d'un appel depuis le shell tel que: ./cx05.3 *.c, argv va contenir (outre le nom du programme lui-même)
 * la liste des fichiers .c du répertoire courant. En effet, le shell va subtiliser les noms des fichiers qui satisfont
 * l'expression *.c à la place de cette expression. S'il n'en trouve pas, l'expression est laissé telle quelle.
 * Même chose si l'expression est entre guillemets: ./cx05.3 "*.c". Dans ce cas, le shell passe *.c au programme.
 *
 * Le tableau envp va lui contenir sensiblement le même chose que la commande env. La seule différence concerne la
 * variable d'environment "_" qui contient le chemin complet du programme exécuté.
 */

#include <stdio.h>

#define str char *

// Affiche une liste de mots, un par ligne
void putwords(const str mots[]) { while (*mots) puts(*mots++); }

int main(int argc, const char *argv[], const char *envp[]) {
    puts("*** argv:"); // Pour plus de clarté dans l'affichage
    putwords(argv);
    puts("*** envp:"); // Pour plus de clarté dans l'affichage
    putwords(envp);
    return 0;
}
