/* *******************************************************
 * Nom           : cx05.2.c
 * Rôle          : Prototype
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx05.2.c -o cx05.2
 * Usage         : ./cx05.2 test
 * *******************************************************/

/* Enoncé:
 * modifier le programme de l'exercice [cx05.1] en plaçant le prototype de putwords() avant la définition de main(),
 * tout en laissant la définition de putwords() après celle de main()!; le compiler, et constater qu'il n'y a plus de
 * conflit...
 */

#include <stdio.h>

#define str char *

void putwords(const str mots[]); // Déclaration du prototype

int main(int k, const str ldc[]) { putwords(ldc) ; return 0; }

void putwords(const str mots[]) { while (*mots) puts(*mots++); } // La fonction avec son code
