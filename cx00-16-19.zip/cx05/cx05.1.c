/* *******************************************************
 * Nom           : cx05.1.c
 * Rôle          : Bonne déclaration
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx05.1.c -o cx05.1
 * Usage         : ./cx05.1 test
 * *******************************************************/

/* Enoncé:
 * arranger le programme [cx05.0] en disposant la définition de putwords() avant celle de main(), le compiler, et
 * constater qu'il n'y a plus de conflit.
 */

#include <stdio.h>

#define str char *

void putwords(const str mots[]) { while (*mots) puts(*mots++); }

int main(int k, const str ldc[]) { putwords(ldc) ; return 0; }

