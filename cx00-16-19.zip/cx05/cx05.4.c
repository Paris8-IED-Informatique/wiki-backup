/* *******************************************************
 * Nom           : cx05.4.c
 * Rôle          : Arguments de main
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx05.4.c -o cx05.4
 * Usage         : ./cx05.4 *.c
 * *******************************************************/

/* Enoncé:
 * en attendant, essayez d'exécuter un programme dont la seule instruction serait un appel à la fonction system(), par
 * exemple:
 * int main() { return system("ls -alF") ; }
 */

#include <stdlib.h>

int main() { return system("ls -alF") ; }
