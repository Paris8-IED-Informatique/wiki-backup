/* *******************************************************
 * Nom           : cx05.0.c
 * Rôle          : Mauvaise déclaration
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx05.0.c -o cx05.0
 * Usage         : ./cx05.0 test
 * *******************************************************/

/* Enoncé:
 * compiler et exécuter le programme ci-dessus; comprenez-vous pourquoi il pose un problème au compilateur?
 */

/* Explications:
 * Dans la fonction main, lorsque le compilateur rencontre putwords, cette fonction n'est pas encore connue car elle
 * est déclarée plus tard dans fichiers. C'était acceptable dans les anciennes version du C, mais plus maintenant et
 * le compilateur va générer une erreur:
 *   error: implicit declaration of function 'putwords' is invalid in C99
 */

#include <stdio.h>

#define str char *

int main(int k, const str ldc[]) { putwords(ldc) ; return 0; }

void putwords(const str mots[]) { while (*mots) puts(*mots++); }
