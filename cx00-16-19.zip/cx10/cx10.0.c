/* *******************************************************
 * Nom           : cx10.0.c
 * Rôle          : Taille des types
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx10.0.c -o cx10.0
 * Usage         : ./cx10.0
 * *******************************************************/

/* Enoncé:
 * ajouter au code ci-dessus les instructions qui donneraient la taille des types long int, float et double!; le
 * compiler, et l'exécuter...
 */

/* Explications:
 * On obtient, par exemple, le résultat suivant:

void : 1
char : 1
short int : 2
int : 4
long long int : 8
char * : 8
long int : 8
float : 4
double : 8

 * Ces valeurs sont dépendantes de l'architecture de l'ordinateur (8, 16, 32, 64 bits) et du compilateur.

 * Remarque: Suivant quel compilateur et quel système d'exploitation vous utilisez, vous pouvez avoir des alertes
 * (warnings) à propos des printf. En effet, le type retourné par sizeof peut être unsigned int ou unsigned long
 * suivant la cible du compilateur (target, 32 bits ou 64 bits).
 */

#include <stdio.h>

int main(void) {
    printf("void : %lu\n", sizeof(void));
    printf("char : %lu\n", sizeof(char));
    printf("short int : %lu\n", sizeof(short int));
    printf("int : %lu\n", sizeof(int));
    printf("long long int : %lu\n", sizeof(long long int));
    printf("char * : %lu\n", sizeof(char *));

    // On ajoute des lignes pour long int, float et double
    printf("long int : %lu\n", sizeof(long int));
    printf("float : %lu\n", sizeof(float));
    printf("double : %lu\n", sizeof(double));
    return 0;
}
