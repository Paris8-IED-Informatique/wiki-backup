/* *******************************************************
 * Nom           : cx10.1.c
 * Rôle          : Taille des types
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx10.1.c -o cx10.1
 * Usage         : ./cx10.1
 * *******************************************************/

/* Enoncé:
 * ajouter à ce programme des variables référençant tous les autres types de donnée!; le compiler, et l'exécuter;
 * le principe ci-dessus est-il valide pour tout type?
 */

/* Explications:
 * On obtient, par exemple, le résultat suivant:

cref : 0x1
sref : 0x2
iref : 0x4
vref : 0x1
llref : 0x8
crref : 0x8
lref : 0x8
fref : 0x4
dref : 0x8

   Ces valeurs sont bien les mêmes que dans l'exercice précédent et donc le principe est valable pour tous ces types.
 */

#include <stdio.h>

int main(void) {
    char * cref = NULL;
    short * sref = NULL;
    int * iref = NULL;

    // On ajoute des lignes pour les autres types
    void * vref = NULL;
    long long int * llref = NULL;
    char ** crref = NULL;
    long int * lref = NULL;
    float * fref = NULL;
    double * dref = NULL;

    printf("cref : %p\n", cref + 1);
    printf("sref : %p\n", sref + 1);
    printf("iref : %p\n", iref + 1);

    // On ajoute des lignes pour les autres types
    printf("vref : %p\n", vref + 1);
    printf("llref : %p\n", llref + 1);
    printf("crref : %p\n", crref + 1);
    printf("lref : %p\n", lref + 1);
    printf("fref : %p\n", fref + 1);
    printf("dref : %p\n", dref + 1);

    return 0 ;
}
