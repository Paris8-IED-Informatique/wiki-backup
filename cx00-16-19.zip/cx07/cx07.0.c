/* *******************************************************
 * Nom           : cx07.0.c
 * Rôle          : Codage ASCII avec argument
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx07.0.c -o cx07.0
 * Usage         : ./cx07.0 127
 * *******************************************************/

/* Enoncé:
 * coder et compiler le programme ci-dessus; le tester avec plein de valeurs différentes, comme 95, 122, ou 256.
 * Que se passe-t-il si on lui donne 275 ou 512?
 */

/* Explications:
 * Pour les valeurs entre 1 et 32, aucun caractère visible n'est affiché. Mais on peut remarquer:
 * - Les valeur 10, 11 et 12 sont suivies d'une ligne vide.
 * - La valeur 27 est suivie d'une indentation sur la ligne suivante
 * - La valeur 32 correspond en fait à un espace
 * En effet, les codes entre 1 et 31 sont des caractères de contrôle.
 * A partir de 257, les mêmes caractères qu'à partir de 1 sont affichés. En effet, les caractères sont ici codés sur
 * un octet et donc la valeur boucle sur 0 quand passe 256 à printf (%c).
 *
 * Si on ne passe pas d'argument au programme, celui-ci plante:
 *   [1]    20004 segmentation fault  ./cx07.0
 * En effet, on essaie d'accéder à une adresse (args[1]) qui n'est pas valide.
 */

#include <stdlib.h>
#include <stdio.h>

void ascii(int);

int main(int k, const char *args[]) {
    ascii(atoi(args[1]));
    return 0;
}

void ascii(int max) {
    int ascii = 0;
    while (ascii++ < max) printf("%d %c\n", ascii, ascii);
}
