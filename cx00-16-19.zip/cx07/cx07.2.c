/* *******************************************************
 * Nom           : cx07.2.c
 * Rôle          : Codage ASCII avec limites min et max
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx07.2.c -o cx07.2
 * Usage         : ./cx07.2 32 127
 * *******************************************************/

/* Enoncé:
 * modifier le programme précédent de sorte qu'il prenne deux valeurs sur la ligne de commande: la première, args [1],
 * servira de borne inférieure à la boucle d'affichage (au lieu d'afficher les codes à partir de 32), tandis que args[2]
 * servira de limite supérieure.
 */

/* Explications:
 * On ajoute un deuxième paramètre à la fonction ascii (min) qui servira de valeur de départ.
 * Comme c'est le while qui incrémente ascii, on démarrage une unité avant et donc le printf recevra la bonne valeur.
 *
 * A noter que si l'on passe quelque chose qui n'est pas un nombre comme premier argument, tout se passe comme si l'on
 * avait passé 0:
 *   ./cx07.2 text 40
 * Encore plus étrange:
 *   ./cx07.2 33text 40
 * se comporte comme si on avait passé 33 comme premier argument. En effet, la fonction atoi a ce comportement. Elle
 * s'arrête au premier caractère qu'elle n'arrive pas à interpréter et retourne ce qu'elle trouvé jusque là. Si elle
 * n'a interprété aucun caractère, elle retourne 0. C'est la raison pour laquelle if faut éviter d'utiliser atoi
 * (voir exercice suivant).
 */

#include <stdlib.h>
#include <stdio.h>

void ascii(int, int); // On modifie le prototype pour le deuxième paramètre

int main(int k, const char *args[]) {
    ascii(atoi(args[1]), atoi(args[2]));
    return 0;
}

// On modifie la déclaration pour le deuxième paramètre
void ascii(int min, int max) {
    int ascii = min - 1; // Valeur de départ (min - 1 car while va tout de suite incrémenter ascii)
    while (ascii++ < max) printf("%d %c\n", ascii, ascii);
}

