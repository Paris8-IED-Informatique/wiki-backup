/* *******************************************************
 * Nom           : cx07.3.c
 * Rôle          : Codage ASCII strtol
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx07.3.c -o cx07.3
 * Usage         : ./cx07.3 32 127
 * *******************************************************/

/* Enoncé:
 * le man de atoi() nous raconte que cette fonction est pourrie, et que d'ailleurs elle est deprecated, dépréciée en
 * faveur de strtol(); et on nous dit comment appeler strtol() à la place: adapter le programme précédent en y
 * remplaçant atoi() par strtol(), et vérifier son bon fonctionnement... Et en programmeur consciencieux, vous irez
 * aussi voir aussi le man de strtol().
 */

/* Explications:
 * Le prototype de strtol est le suivant:
 *   long strtol(const char *str, char **str_end, int base);
 * avec:
 * - str:     la chaine de caractères à interpréter
 * - str_end: un pointeur sur un pointeur de caractère. Si n'est pas NULL, strtol va mettre l'adresse du premier
 * caractère qui n'a pas été interprété à cette adresse.
 * - base:    la base (de 0 à 36) à utiliser pour lire et convertir la chaine de caractères.
 * La valeur de retour est la suivante:
 * - Si la conversion a pu se faire, strtol retourne la valeur (un long). A noter que comme atoi, strtol s'arrête au
 * premier caractère qui n'a pas pu être converti. L'adresse de ce caractère est alors indiqué par str_end (si str_end
 * n'est pas NULL).
 * - Si la conversion donne un nombre qui ne peut pas être représenté par la valeur de retour (un long), la valeur
 * minimum ou maximum est retournée et la variable globale errno est mise à ERANGE.
 * - Si aucune conversion n'est possible, la valeur 0 est retournée.
 *
 * Dans le code modifié ci-dessous, nous allons traiter tous ces cas.
 */

#include <stdlib.h>
#include <stdio.h>
#include <errno.h>

void ascii(int, int); // Prototype

int main(int k, const char *args[]) {
    char* end; // Va contenir l'adresse du premier caracatère qui n'a pas été lu

    long min = strtol(args[1], &end, 10); // en base 10
    // Si on a rien pu lire, ou s'il reste des caractères qui n'ont pas été lu...
    if(end == args[1] || *end != 0) {
        puts("Le premier paramètre ne contient pas un nombre");
        return 1;
    }
    // S'il y a eu une erreur lors de la conversion
    if(errno == ERANGE) {
        puts("Le premier paramètre est trop grand ou trop petit");
        return 1;
    }

    long max = strtol(args[2], &end, 10); // en base 10
    // Si on a rien pu lire, ou s'il reste des caractères qui n'ont pas été lu...
    if(end == args[1] || *end != 0) {
        puts("Le premier paramètre ne contient pas un nombre");
        return 1;
    }
    // S'il y a eu une erreur lors de la conversion
    if(errno == ERANGE) {
        puts("Le premier paramètre est trop grand ou trop petit");
        return 1;
    }

    ascii(min, max);
    return 0;
}

// On modifie la déclaration pour le deuxième paramètre
void ascii(int min, int max) {
    int ascii = min - 1; // Valeur de départ (min - 1 car while va tout de suite incrémenter ascii)
    while (ascii++ < max) printf("%d %c\n", ascii, ascii);
}

