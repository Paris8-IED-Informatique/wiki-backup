/* *******************************************************
 * Nom           : cx07.1.c
 * Rôle          : Codage ASCII avec argument, à partir de 32
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx07.1.c -o cx07.1
 * Usage         : ./cx07.1 127
 * *******************************************************/

/* Enoncé:
 * modifier le programme précédent de sorte qu'au lieu d'afficher les codes à partir de 0, il démarre à 32, la première
 * valeur affichable.
 */

/* Explications:
 * Il suffit de modifier la valeur de départ (ascii). Comme c'est le while qui incrémente ascii, on démarrage à 31 et
 * donc le printf recevra d'abord 32.
 */

#include <stdlib.h>
#include <stdio.h>

void ascii(int);

int main(int k, const char *args[]) {
    ascii(atoi(args[1]));
    return 0;
}

void ascii(int max) {
    int ascii = 31; // On modifie la valeur de départ
    while (ascii++ < max) printf("%d %c\n", ascii, ascii);
}

