/* *******************************************************
 * Nom           : cx04.1.c
 * Rôle          : Chaine de caractères: pointeurs
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx04.1.c -o cx04.1
 * Usage         : ./cx04.1
 * *******************************************************/

/* Enoncé:
 * compiler et exécuter le programme ci-dessus: les 2 variables pointent-elles bien sur le même objet, à la même
 * adresse en mémoire?
 */

/* Explications:
 * Le résultat de l'exécution est similaire à:
 *   format1 @ 0x7ffee65deef0 : 0x109623f91
 *   format2 @ 0x7ffee65deee8 : 0x109623f91
 * Les deux variables format1 et format2 ont des adresses différentes mais pointent toutes les deux sur la même
 * adresse (la chaine de caractères).
 */

#include <stdio.h>

int main (void) {
    char *format1 = "%s @ %p : %p\n";
    char *format2 = "%s @ %p : %p\n";
    printf(format1, "format1", &format1, &*format1);
    printf(format2, "format2", &format2, &*format2);
    return 0;
}
