/* *******************************************************
 * Nom           : cx04.0.c
 * Rôle          : Chaine de caractères: pointeurs et caractères
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx04.0.c -o cx04.0
 * Usage         : ./cx04.0
 * *******************************************************/

/* Enoncé:
 * copier et tester le programme ci-dessus!– on reviendra bientôt sur la fonction printf().
 */


#include <stdio.h>

int main() {
    char *premier = "programme";
    printf(" premier @ %p\n", &premier);
    printf(" premier : %p\n", premier);
    printf("*premier : '%c'\n", *premier);
    return 0;
}