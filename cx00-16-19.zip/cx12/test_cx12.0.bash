#!/usr/bin/env bash
# *******************************************************
# Nom           : cx12.0.bash
# Rôle          : Tests unitaires du programme cx12.0
# Auteur        : Britney Spears
# Version       : 1.0
# Date          : 2021-04-28
# Licence       : L1 PROGC
# *******************************************************
# Usage         : bash cx12.0.bash
# *******************************************************

# On compile le programme
../compile cx12.0

# On réalise plusieurs tests et on écrit les résultats dans test_cx12.0.txt
{
  ./cx12.0 ""
  ./cx12.0 a
  ./cx12.0 ab
  ./cx12.0 abcd
  ./cx12.0 abcde
  ./cx12.0 abcdef
  ./cx12.0 abcdefg
  ./cx12.0 abcdefgh
  ./cx12.0 abcdefghi
  ./cx12.0 abcdefghij
  ./cx12.0 a A 0
  ./cx12.0 ab AB 01
  ./cx12.0 abcdef ABCDE 0123
  ./cx12.0 abcdef "" 0123
  ./cx12.0 9876543210 azertyuiop qsdfghjklm wxcvbn
} > test_cx12.0.txt

# On compare test_cx12.0.txt avec la sortie de référence test_cx12.0-ref.txt
# Affichage sur deux colonnes (-y) et indique aussi si les fichiers sont identiques (-s)
diff -s -y test_cx12.0.txt test_cx12.0-ref.txt

