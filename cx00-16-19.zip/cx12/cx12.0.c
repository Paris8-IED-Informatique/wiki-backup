/* *******************************************************
 * Nom           : cx12.0.c
 * Rôle          : Inversion, sur place, du contenu des arguments
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx12.0.c -o cx12.0
 * Usage         : ./cx12.0 9876543210 azertyuiop qsdfghjklm wxcvbn
 * *******************************************************/

/* Enoncé:
 * coder la fonction de prototype int inverse (char *) qui accepte une chaîne de longueur quelconque, y compris la
 * chaîne vide, et inverse, sur place, l'ordre des caractères de cette chaîne; elle retourne 1 si tout se passe bien,
 * et 0 sinon.
 */

/* Explications:
 * Nous devons connaitre la longueur de la chaine de caractères. Celle-ci est donnée par la fonction strlen. Il suffit
 * alors d'échanger le premier caractère avec le dernier, etc. On utilise un boucle for vu qu'elle est introduite juste
 * avant dans le cours. L'échange de caractère suit ce schéma (length est la longueur de la chaine):
 *
 *   -----------------------
 *   v                     v
 *  --------------------------------
 *  | 0 | 1 | 2 | ... | length - 1 |
 *  --------------------------------
 *
 *  On échange le 1er caractère (d'indice 0) avec le dernier (d'indice length - 1), le deuxième (d'indice 1) avec
 *  l'avant dernier (d'indice length - 2), etc. On s'arrête à la moitié de la chaine. A noter que si la chaine est vide,
 *  notre algorithme fonctionne: la boucle for s'arrête avant d'avoir commencée et rien n'est changé.
 *
 *  Notre algorithme (et le cours) suppose que chaque caractère peut être représenté par un char. Or ce n'est pas le cas
 *  en UTF-8. Si on exécute le programme avec des caractères UTF-8 plus grand que 127 càd sur plusieurs octets, le
 *  programme va échanger ces octets et produire un résultat invalide.
 *
 *  Les tests unitaires de ce programme sont dans test_cx12.0.c avec la sortie de référence test_cx12.0-ref.txt.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h> // Pour strlen

void usage(const char * program); // Prototype

// Inverse une chaine de caractère sur place
int inverse1(char *str) {
    if(!str) return 0; // Au cas où...
    int length = strlen(str); // La longueur de la chaine
    for(int i = 0; i < length / 2; ++i) { // Boucle depuis le début jusqu'à la moitié de la chaine
        char tmp = str[i]; // On se souvient de la valeur pour l'échange
        str[i] = str[length - 1 - i]; // On met le caractère correspondant
        str[length - 1 - i] = tmp;
    }
    return 1; // Il est toujours possible d'inverser
}

int inverse(char *str) {
    if(!str) return 0; // Au cas où...
    int length = strlen(str); // La longueur de la chaine
    // Tant que str et end ne se sont pas rejoint...
    for(char* end = str + length - 1; end > str; ++str, --end) {
        char tmp = *str; // On se souvient de la valeur pour l'échange
        *str = *end; // On met le caractère correspondant
        *end = tmp;
    }
    return 1; // Il est toujours possible d'inverser
}

int main(int argc, char * argv[]) {
    if(argc < 2) usage(*argv);

    for(int i = 1; i < argc; ++i) { // On démarre à 1 puisque l'indice 0 est le nom du programme
        printf("%s : ", argv[i]);
        if (inverse(argv[i])) puts(argv[i]); else puts("impossible");
    }
    return 0;
}

// Explique comment utiliser le programme
void usage(const char * program) {
    printf("Inverse les arguments.\n\n");
    printf("Usage : %s arg1 ... argn\n\n", program);
    printf("Il est possible de spécifier 1 ou plusieurs arguments. Le programme affiche l'argument puis son inverse.\n\n");
    printf("Exemples d'utilisation:\n");
    printf("%s ABCDEF\n", program);
    printf("%s 9876543210 azertyuiop qsdfghjklm wxcvbn\n", program);
    exit(1);
}
