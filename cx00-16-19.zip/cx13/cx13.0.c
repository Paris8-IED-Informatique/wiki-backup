/* *******************************************************
 * Nom           : cx13.0.c
 * Rôle          : Un (presque) équivalent de cat
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx13.0.c -o cx13.0
 * Usage         : ./cx13.0 < ../cx11/cx11.2.c > texte
 * *******************************************************/

/* Enoncé:
 * compléter le programme, et le tester dans la fenêtre de terminal!; comme avec cat, vous pouvez rediriger stdin pour
 * qu'il lise un « vrai » fichier, et vous pouvez aussi rediriger stdout pour écrire dans un « vrai » fichier, auquel
 * cas il réalise une copie du fichier dans l'autre:
 *   cx13.0 < cx11.2.c > texte
 * Sinon, il prendra les caractères lus au clavier – et les répercutera directement sur l'écran après chaque saut de
 * ligne (ou '\n')!; vous devrez alors ajouter vous-même le caractère de FIN DE DONNÉE sous la forme d'un ^D
 * (CONTRÔLE D). Attention: la FIN DE DONNÉE, dans ce cas, doit être envoyée en début de ligne, autrement dit,
 * immédiatement après un LINE FEED, ou saut de ligne.
 */

/* Explications:
 * On ajoute simplement #include <stdio.h> pour avoir le prototype de getchar et de putchar.
 */

#include <stdio.h>


int main(void)
{
    signed char x;
    while((x = getchar()) != EOF) putchar(x);
    return 0;
}
