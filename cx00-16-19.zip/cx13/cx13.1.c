/* *******************************************************
 * Nom           : cx13.1.c
 * Rôle          : cat avec affichage du nombre de caractères
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx13.1.c -o cx13.1
 * Usage         : ./cx13.1 < ../cx11/cx11.2.c
 * *******************************************************/

/* Enoncé:
 * modifier le programme précédent pour qu'en plus il compte les caractères qu'il a lu, et en affiche le nombre une
 * fois le while terminé.
 */

/* Explications:
 * On ajoute un compteur de caractèrs (count) que l'on incrémente dans la boucle while.
 */

#include <stdio.h>


int main(void)
{
    unsigned int count = 0; // Nombre de caractères, on part de 0
    signed char x;
    while((x = getchar()) != EOF) {
        putchar(x);
        ++count; // Un caractère de plus, donc on incrémente count
    }
    printf("Nombre de caractères: %u\n", count);
    return 0;
}
