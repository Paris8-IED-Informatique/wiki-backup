/* *******************************************************
 * Nom           : cx13.2.c
 * Rôle          : cat avec affichage du nombre de retour à la ligne
 * Auteur        : Britney Spears
 * Version       : 1.0
 * Date          : 2021-04-28
 * Licence       : L1 PROGC
 * *******************************************************
 * Compilation   : gcc -Wall cx13.2.c -o cx13.2
 * Usage         : ./cx13.2 < ../cx11/cx11.2.c
 * *******************************************************/

/* Enoncé:
 * modifier le programme précédent de sorte qu'il se contente de compter le nombre de sauts de ligne rencontrés, et
 * affiche ce nombre une fois le while terminé.
 */

/* Explications:
 * Au lieu de compter tous les caractères, on ne compte que les retours à la ligne (\n).
 */

#include <stdio.h>


int main(void) {
    unsigned int count = 0; // Nombre de caractères, on part de 0
    signed char x;
    while((x = getchar()) != EOF) {
        putchar(x);
        if(x == '\n') // Un retour à la ligne ?
            ++count; // oui, donc on incrémente count
    }
    printf("Nombre de retours à la ligne: %u\n", count);
    return 0;
}
